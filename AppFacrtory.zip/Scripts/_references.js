﻿
/// <reference path="..\..\Wells_Fargo\Scripts\jquery-1.11.2.js"/>
/// <reference name="..\..\Wells_Fargo\Scripts\MicrosoftAjax.js" />
/// <reference path="..\..\Wells_Fargo\Scripts\daf-resources.js"/>
/// <reference path="..\..\Wells_Fargo\Scripts\daf.js"/>
/// <reference path="..\..\Wells_Fargo\Scripts\daf-menus.js"/>
/// <reference path="..\..\Wells_Fargo\Scripts\touch.js"/>
/// <reference path="..\..\Wells_Fargo\Scripts\touch-charts.js"/>
/// <reference path="..\..\WebApp\touch\jquery.mobile-1.4.5.js"/>
