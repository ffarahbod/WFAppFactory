﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Security;
using Wells_Fargo.Data;

namespace Wells_Fargo.Rules
{
	public partial class ctlNSA_View_DraftBusinessRules : Wells_Fargo.Rules.SharedBusinessRules
    {
        
        /// <summary>
        /// Rule "cmdSubmit" implementation:
        /// This method will execute in any view for an action
        /// with a command name that matches "Custom" and argument that matches "Submit".
        /// </summary>
        [Rule("r100")]
        public void r100Implementation(int? viewid, string viewname, string useridentity)
        {
           string sconditon = "";

           SqlText sql = new SqlText("Select [ViewFilter] from View_Filter_Draft where [userIdentity]='" + Context.User.Identity.Name + "'");
            if (sql.Read())
            {
               if (sql.Reader.GetValue(0)!=null)  sconditon = sql.Reader.GetValue(0).ToString();
            }
            sql.Close();
            
            sql = new SqlText("Update NSA_View set ViewSelected=0 where useridentity='" + Context.User.Identity.Name + "'");
            sql.ExecuteNonQuery();
            sql.Close();

            string s = "INSERT INTO [dbo].[NSA_View] ([viewname],[ViewCondition],[viewispublic],[useridentity],[ViewSelected]) VALUES (@viewname,@conditon,@ispublic,@UserName,@selected)";
            sql = new SqlText(s);
            sql.AddParameter("@viewname", viewname);
            sql.AddParameter("@conditon", sconditon);
            sql.AddParameter("@ispublic", 0);
            sql.AddParameter("@UserName", Context.User.Identity.Name);
            sql.AddParameter("@selected", 1);
            sql.ExecuteNonQuery();
            sql.Close();

            sql = new SqlText("SELECT IDENT_CURRENT('NSA_VIEW')");
            
            if (sql.Read ())
            {
                viewid = int.Parse (sql.Reader.GetValue(0).ToString());

            }
            sql.Close ();
           
            string stransfer =@"begin Insert into NSA_PROJECT.dbo.NSA_View_Fields(viewid,tablename,fieldid,visible,orderby,username,sequence) select " + viewid + ",Tablename,fieldid,visible,orderby,'" + Context.User.Identity.Name   + "',sequence from NSA_PROJECT.dbo.NSA_View_Fields_Draft where Visible=1 or Orderby is not null end";

            sql = new SqlText(stransfer);
            sql.ExecuteNonQuery();
            sql.Close();

            sql = new SqlText("Delete from  NSA_View_Fields_Draft where username ='" + Context.User.Identity.Name + "'");
            sql.ExecuteNonQuery();
            sql.Close();

            sql = new SqlText("Delete from  View_Filter_Draft where userIdentity ='" + Context.User.Identity.Name + "'");
            sql.ExecuteNonQuery();
            sql.Close();

            Result.NavigateUrl = "AllItems.aspx";
        }
    }
}
