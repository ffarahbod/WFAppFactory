﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Security;
using Wells_Fargo.Data;

namespace Wells_Fargo.Rules
{
	public partial class ctlIssueBusinessRules : Wells_Fargo.Rules.SharedBusinessRules
    {
        
        /// <summary>
        /// Rule "setstatusbyendate" implementation:
        /// This method will execute in any view for an action
        /// with a command name that matches "Calculate|Update".
        /// </summary>
        [Rule("r102")]
        public void r102Implementation(int? issueNumber, int? iD, string iSSUEType, FieldValue iSSUEStatus, string iSSUEPriority, string issueOwner, DateTime? issueStart, DateTime? issueEnd, string issuenotes, string createuser, DateTime? createdate, string updateuser, DateTime? updatedate, string workstream)
        {
            FieldValue ModifiedOnFieldValue = SelectFieldValueObject("ISSUESTATUS");
            object ModifiedOnCodeValue = "Resolved";

            if (issueEnd!=null)
            {
                AddFieldValue("ISSUESTATUS", ModifiedOnCodeValue);
                               
            }
        }
    }
}
