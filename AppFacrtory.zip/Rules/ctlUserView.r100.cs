﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Security;
using Wells_Fargo.Data;

namespace Wells_Fargo.Rules
{
	public partial class ctlUserViewBusinessRules : Wells_Fargo.Rules.SharedBusinessRules
    {
        
        /// <summary>
        /// Rule "deletechildfields" implementation:
        /// This method will execute in any view for an action
        /// with a command name that matches "Delete".
        /// </summary>
        [Rule("r100")]
        public void r100Implementation(int? viewid, string viewname, string useridentity)
        {
            SqlText sql = new SqlText("delete from NSA_View_Fields where viewid=" + viewid);
            sql.ExecuteNonQuery();
            sql.Close();
        }
    }
}
