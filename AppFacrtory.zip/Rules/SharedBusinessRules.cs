using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.DirectoryServices.ActiveDirectory;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Xml;
using System.Xml.XPath;
using Wells_Fargo.Data;

namespace Wells_Fargo.Rules
{
	public class SharedBusinessRules : BusinessRules
	{
		public SharedBusinessRules()
		{
		}

		[ControllerAction("NSA_Address_Info", "grid1", "Select", ActionPhase.After)]
		private void AfterSelectInGridSearch()
		{
			string userName = base.Context.User.Identity.Name;
		}

		protected override void AfterSqlAction(ActionArgs args, ActionResult result)
		{
			FieldValue v;
			SqlText t2;
			FieldValue[] values;
			int num;
			object[] name;
			try
			{
				string site_alias = "";
				string id = "";
				string sname = base.Context.User.Identity.Name;
				string commandName = args.CommandName;
				if (commandName != null)
				{
					if (commandName == "Update")
					{
						SqlText finduser = new SqlText(string.Concat("SELECT [Full Name] FROM [NSA_PROJECT].[dbo].[NSA_USERS]  where 'AD-ENT\\' + [Ad-ENT ID] = '", base.Context.User.Identity.Name, "'"));
						if (finduser.Read())
						{
							sname = finduser.Reader.GetValue(0).ToString();
						}
						try
						{
							finduser.Close();
						}
						catch
						{
						}
						if ((sname == null ? true : sname.Trim().Length == 0))
						{
							sname = base.Context.User.Identity.Name;
						}
						values = args.Values;
						for (num = 0; num < (int)values.Length; num++)
						{
							v = values[num];
							if (v.Name == "SITE_ALIAS")
							{
								site_alias = v.Value.ToString();
							}
							if (v.Name == "ID")
							{
								id = v.Value.ToString();
							}
						}
					}
				}
				commandName = args.CommandName;
				if (commandName != null)
				{
					if (commandName == "Update")
					{
						values = args.Values;
						for (num = 0; num < (int)values.Length; num++)
						{
							v = values[num];
							if (v.Modified & !v.ReadOnly)
							{
								object v1 = v.OldValue;
								object v2 = v.NewValue;
								string v3 = v.Name;
								SqlText sql = null;
								sql = new SqlText(string.Concat("Select [usergroup],[ccusers],[includedfields],[emailsubject],[emailbody],[notificationgroups] from [NSA_PROJECT].[dbo].[NSA_Email_Trigger] where FieldNAME='", v.Name, "'"));
								if (sql.Read() )
								{
									string includedfield = "";
									includedfield = sql.Reader.GetValue(2).ToString();
									includedfield = includedfield.Replace(",", "],[");
									includedfield = string.Concat("[", includedfield, "]");
									string userto = sql.Reader.GetValue(0).ToString();
									userto = userto.Replace(",", ";");
									string ccusers = "";
									string notifygroup = null;
									notifygroup = sql.Reader.GetValue(5).ToString();
									if ((notifygroup == null ? false : notifygroup != ""))
									{
										string[] sqlnotify = notifygroup.Split(new char[] { ',' });
										for (int i = 0; i < (int)sqlnotify.Length; i++)
										{
											try
											{
												string s22 = sqlnotify[i].ToString();
												SqlText ng22 = new SqlText(s22.Replace("?", site_alias));
												if (ng22.Read())
												{
													SqlText ng = new SqlText(string.Concat("Select NSA_USERS.[E-mail Address] from nsa_project.dbo.NSA_USERS where nsa_project.dbo.NSA_USERS.[Full Name] ='", ng22.Reader.GetValue(0).ToString(), "'"));
													if (ng.Read())
													{
														userto = string.Concat(userto, ";", ng.Reader.GetValue(0).ToString());
													}
													ng.Close();
												}
												ng22.Close();
											}
											catch
											{
											}
										}
									}
									ccusers = sql.Reader.GetValue(1).ToString();
									try
									{
										ccusers = ccusers.Replace(",", ";");
									}
									catch
									{
									}
									string emailsubject = "";
									string oldv = "";
									oldv = (v.OldValue != null ? v.OldValue.ToString() : "");
									string newval = "";
									newval = (v.NewValue != null ? v.NewValue.ToString() : "");
									emailsubject = sql.Reader.GetValue(3).ToString();
									string emailbody = "";
									emailbody = sql.Reader.GetValue(4).ToString();
									SqlText sqlemail = new SqlText("[dbo].[SendEmail2]");
									sqlemail.Command.CommandType = CommandType.StoredProcedure;
									sqlemail.AssignParameter("@siteid", id);
									sqlemail.AssignParameter("@site_code", site_alias);
									sqlemail.AssignParameter("@changeduser", sname);
									sqlemail.AssignParameter("@columnname", v.Name);
									sqlemail.AssignParameter("@oldvalue", oldv);
									sqlemail.AssignParameter("@StringCCUsers", ccusers);
									sqlemail.AssignParameter("@StringUserGroup", userto);
									sqlemail.AssignParameter("@newvalue", newval);
									sqlemail.AssignParameter("@StringFieldsIncluded", includedfield);
									sqlemail.AssignParameter("@StringemailSubject", emailsubject);
									sqlemail.AssignParameter("@StringEmailBody", emailbody);
									sqlemail.AssignParameter("@colup", v.Name);
									if (v.OldValue != v.NewValue)
									{
										if ((v.OldValue != DBNull.Value ? true : v.NewValue != DBNull.Value))
										{
											if ((v.OldValue != null ? true : v.NewValue != null))
											{
												sqlemail.ExecuteNonQuery();
												sqlemail.Close();
											}
										}
									}
								}
								try
								{
									sql.Close();
								}
								catch
								{
								}
								sql = new SqlText(string.Concat("Select * from [NSA_PROJECT].[dbo].[NSA_Field_Info] where FieldId='", v.Name, "' and History=1"));
								bool b = sql.Read();
								sql.Close();
								if (b)
								{
									string[] strArrays = new string[] { "Select * from NSA_History where DataElement='", v.Name, "' and SITE_ALIAS='", site_alias, "'" };
									sql = new SqlText(string.Concat(strArrays));
									if (!sql.Read())
									{
										name = new object[] { "insert into NSA_History ([DataElement],[OriginalDate],ChangedDate,[UpdateUser],[Previous],[New],[SITE_ALIAS],ID) values('", v.Name, "',getdate(),getdate(),'", base.Context.User.Identity.Name, "','", v.OldValue, "','", v.NewValue, "','", site_alias, "',", id, ")" };
										t2 = new SqlText(string.Concat(name));
										t2.ExecuteNonQuery();
										t2.Close();
									}
									else
									{
										name = new object[] { "update NSA_History set [ChangedDate]=getDate(),[UpdateUser]=' ", base.Context.User.Identity.Name, "',[Previous]='", v.OldValue, "',[New]='", v.NewValue, "', ID=", id, " where DataElement='", v.Name, "' and SITE_ALIAS='", site_alias, "'" };
										t2 = new SqlText(string.Concat(name));
										t2.ExecuteNonQuery();
										t2.Close();
									}
									sql.Close();
								}
							}
						}
					}
				}
			}
			catch
			{
			}
		}

		[ControllerAction("NSA_Address_Info", "Custom", "BandwidthUpgrades")]
		public void BandwidthUpgrades1()
		{
			FilterValue[] filterValue = new FilterValue[2];
			object[] objArray = new object[] { "N" };
			filterValue[0] = new FilterValue("IPTYNexisting", RowFilterOperation.Equal, objArray);
			objArray = new object[] { "OOS" };
			filterValue[1] = new FilterValue("BndwdthUpgrdyesno", RowFilterOperation.DoesNotEqual, objArray);
			base.AssignFilter(filterValue);
			base.Result.Refresh();
		}

		[ControllerAction("NSA_Address_Info", "Custom", "Navigate")]
		public void BeforeNavigate()
		{
			string s = base.ActionData;
			string suser = "";
			suser = base.Context.User.Identity.Name;
			SqlText sql = new SqlText(string.Concat("Update NSA_View set ViewSelected=0 where useridentity='", suser, "'"));
			sql.ExecuteNonQuery();
			sql.Close();
			sql = new SqlText(string.Concat("Update NSA_View set ViewSelected=1 where viewid=", s));
			sql.ExecuteNonQuery();
			sql.Close();
			base.Result.NavigateUrl = "AllItems.aspx";
		}

		[ControllerAction("NSA_Address_Info", "Custom", "BriefStatus")]
		public void BriefStatus1()
		{
			FilterValue[] filterValue = new FilterValue[1];
			object[] objArray = new object[] { "OOS" };
			filterValue[0] = new FilterValue("ReadinessDeploy", RowFilterOperation.DoesNotEqual, objArray);
			base.AssignFilter(filterValue);
			base.Result.Refresh();
		}

		protected override void EnumerateDynamicAccessControlRules(string controllerName)
		{
		}

		private string getUserDisplayName()
		{
			IntPtr bufPtr;
			string empty;
			StringBuilder username = new StringBuilder(1024);
			uint userNameSize = (uint)username.Capacity;
			if (0 == SharedBusinessRules.GetUserNameEx(3, username, ref userNameSize))
			{
				if (0 != SharedBusinessRules.GetUserNameEx(2, username, ref userNameSize))
				{
					try
					{
						if (0 == SharedBusinessRules.NetUserGetInfo(DomainController.FindOne(new DirectoryContext(DirectoryContextType.Domain, Regex.Replace(username.ToString(), "(.+)\\\\.+", "$1"))).IPAddress, Regex.Replace(username.ToString(), ".+\\\\(.+)", "$1"), 10, out bufPtr))
						{
							SharedBusinessRules.USER_INFO_10 userInfo = (SharedBusinessRules.USER_INFO_10)Marshal.PtrToStructure(bufPtr, typeof(SharedBusinessRules.USER_INFO_10));
							empty = Regex.Replace(userInfo.usri10_full_name, "(\\S+), (\\S+)", "$2 $1");
							return empty;
						}
					}
					finally
					{
						SharedBusinessRules.NetApiBufferFree(out bufPtr);
					}
				}
				empty = string.Empty;
			}
			else
			{
				empty = Regex.Replace(username.ToString(), "(\\S+), (\\S+)", "$2 $1");
			}
			return empty;
		}

		[DllImport("secur32.dll", CharSet=CharSet.Auto, ExactSpelling=false)]
		private static extern int GetUserNameEx(int nameFormat, StringBuilder userName, ref uint userNameSize);

		[ControllerAction("NSA_Address_Info", "Custom", "HardwareView")]
		public void HardwareView1()
		{
			FilterValue[] filterValue = new FilterValue[1];
			object[] objArray = new object[] { "OOS" };
			filterValue[0] = new FilterValue("WLANDeploy", RowFilterOperation.DoesNotEqual, objArray);
			base.AssignFilter(filterValue);
			base.Result.Refresh();
		}

        [ControllerAction("NSA_INVENTORY_STAGE", "Select", ActionPhase.After)]
        public void SelectControllerInventory_Request_After()
        {
            if (base.Page.Rows.Count > 0)
            {
                base.Result.HighlightFirstRow();
            }
            Result.ExecuteOnClient("$appfactory.find('NSA_ORDER_STAGE','Controller').sync();");
            Result.ExecuteOnClient("$appfactory.find('NSA_REQUEST_STAGE','Controller').sync();");
        }

		[ControllerAction("NSA_Address_Info", "Custom", "HaveWLANSitesCompleted")]
		public void HaveWLANSitesCompleted1()
		{
			FilterValue[] filterValue = new FilterValue[1];
			object[] objArray = new object[] { "WLAN Installed/Live", "WLAN Completed/Invoiced", "WLAN Install Acutal Date" };
			filterValue[0] = new FilterValue("WLANStatus", RowFilterOperation.Includes, objArray);
			base.AssignFilter(filterValue);
			base.Result.Refresh();
		}

		[ControllerAction("NSA_Address_Info", "Custom", "IPT")]
		public void IPT1()
		{
			FilterValue[] filterValue = new FilterValue[1];
			object[] objArray = new object[] { "N" };
			filterValue[0] = new FilterValue("IPTYNexisting", RowFilterOperation.Equal, objArray);
			base.AssignFilter(filterValue);
			base.Result.Refresh();
		}

		[ControllerAction("NSA_Address_Info", "Custom", "IssueTracking")]
		public void IssueTracking1()
		{
			FilterValue[] filterValue = new FilterValue[1];
			object[] objArray = new object[] { "Escalate", "In-Progress", "OK to Resched" };
			filterValue[0] = new FilterValue("ISSUEStatus", RowFilterOperation.Includes, objArray);
			base.AssignFilter(filterValue);
			base.Result.Refresh();
		}

		[DllImport("netapi32.dll", CharSet=CharSet.Unicode, ExactSpelling=true)]
		private static extern long NetApiBufferFree(out IntPtr bufPtr);

		[DllImport("netapi32.dll", CharSet=CharSet.Unicode, ExactSpelling=true)]
		private static extern int NetUserGetInfo(string serverName, string userName, int level, out IntPtr bufPtr);

		[ControllerAction("NSA_Address_Info", "Custom", "NetworkDesignIPT")]
		public void NetworkDesignIPT1()
		{
			FilterValue[] filterValue = new FilterValue[2];
			object[] objArray = new object[] { "Y" };
			filterValue[0] = new FilterValue("IPTYNexisting", RowFilterOperation.Equal, objArray);
			objArray = new object[] { "OOS" };
			filterValue[1] = new FilterValue("WLANDeploy", RowFilterOperation.DoesNotEqual, objArray);
			base.AssignFilter(filterValue);
			base.Result.Refresh();
		}

		[ControllerAction("NSA_Address_Info", "Custom", "NetworkDesignWLAN")]
		public void NetworkDesignWLAN1()
		{
			FilterValue[] filterValue = new FilterValue[1];
			object[] objArray = new object[] { "OOS" };
			filterValue[0] = new FilterValue("WLANDeploy", RowFilterOperation.DoesNotEqual, objArray);
			base.AssignFilter(filterValue);
			base.Result.Refresh();
		}

		[ControllerAction("NSA_Address_Info", "Custom", "NetworkSecurityView")]
		public void NetworkSecurityView1()
		{
			FilterValue[] filterValue = new FilterValue[3];
			object[] objArray = new object[] { "WSSI Asgn Needed", "WSSI Asgn Complete" };
			filterValue[0] = new FilterValue("NetSecStatus", RowFilterOperation.DoesNotInclude, objArray);
			objArray = new object[] { "WSSI" };
			filterValue[1] = new FilterValue("WSSIMonitor", RowFilterOperation.Equal, objArray);
			objArray = new object[] { "ISSUE" };
			filterValue[2] = new FilterValue("WLANDeploy", RowFilterOperation.DoesNotEqual, objArray);
			base.AssignFilter(filterValue);
			base.Result.Refresh();
		}

		[ControllerAction("NSA_Address_Info", "Custom", "Refresh")]
		private void RefreshNSAAddress()
		{
			base.Result.ExecuteOnClient("javascript:document.location.href='/NSA/Pages/NSA_Address_Info.aspx';");
			string userName = base.Context.User.Identity.Name;
		}

		[ControllerAction("NSA_Address_Info", "Custom", "ReverseLogisticsSched")]
		public void ReverseLogisticsSched1()
		{
			FilterValue[] filterValue = new FilterValue[1];
			object[] objArray = new object[] { "OOS" };
			filterValue[0] = new FilterValue("WLANDeploy", RowFilterOperation.DoesNotEqual, objArray);
			base.AssignFilter(filterValue);
			base.Result.Refresh();
		}

		[ControllerAction("NSA_Site_MAC_Floor", "grid1", "Select", ActionPhase.After)]
		public void SelectController1After()
		{
			if (base.Page.Rows.Count > 0)
			{
				base.Result.HighlightFirstRow();
			}
		}

		[ControllerAction("IPT", "grid1", "Select", ActionPhase.After)]
		public void SelectController2After()
		{
			if (base.Page.Rows.Count > 0)
			{
				base.Result.HighlightFirstRow();
			}
		}

		[ControllerAction("BanwidthUpgrade1", "cktUpgrade", "Select", ActionPhase.After)]
		public void SelectController3After()
		{
			if (base.Page.Rows.Count > 0)
			{
				base.Result.HighlightFirstRow();
			}
		}

		[ControllerAction("BanwidthUpgrade1", "Select", ActionPhase.After)]
		[ControllerAction("ctlEquipmentMgmt", "Select", ActionPhase.After)]
		[ControllerAction("ctlIPTBranchDiscovery", "Select", ActionPhase.After)]
		[ControllerAction("ctlIPTBranchDiscovery", "Select", ActionPhase.After)]
		[ControllerAction("ctlIPTCircuitUpgrade", "Select", ActionPhase.After)]
		[ControllerAction("ctlIPTProjectInformation", "Select", ActionPhase.After)]
		[ControllerAction("ctlSiteReadinessEUCCoordination", "Select", ActionPhase.After)]
		[ControllerAction("ctlSiteReadinessEUCCoordination", "Select", ActionPhase.After)]
		[ControllerAction("ctlSiteReadinessIPTBOM", "Select", ActionPhase.After)]
		[ControllerAction("ctlSiteReadinessprojectInfo", "Select", ActionPhase.After)]
		[ControllerAction("NSA_Address_Info2", "Select", ActionPhase.After)]
		public void setcktrtfooter()
		{
			string str1;
			string str2;
			char[] chrArray;
			string str3;
			bool flag;
			SqlText sqlText;
			SqlText sqlText1;
			string[] strArrays;
			DataField dataField;
			string str4;
			string str5;
			SqlText sqlText2;
			string[] strArrays2;
			DataField dataField1;
			string str6;
			char[] chrArray1;
			string[] strArrays1;
			string str = "   <style>\r\n {\r\n  display: none;\r\n}\r\n\r\n.toggle-box1 + label {\r\n  cursor: pointer;\r\n  display: block;\r\n  font-weight:lighter;\r\n  text-decoration: underline;\r\n  line-height: 21px;\r\n  color:#3565a5;\r\n  margin-bottom: 5px;\r\n\r\n}\r\n\r\n.toggle-box1 + label + div {\r\n  display: none;\r\n  margin-bottom: -2px;\r\n}\r\n\r\n.toggle-box1:checked + label + div {\r\n  display: block;\r\n}\r\n\r\n.toggle-box1 + label:before {\r\n  background-color: #3565a5;\r\n  -webkit-border-radius: 10px;\r\n  -moz-border-radius: 10px;\r\n  border-radius: 5px;\r\n  color: #FFFFFF;\r\n  display: block;\r\n  float: right;\r\n  font-weight: bold;\r\n  height: 0px;\r\n  line-height: 20px;\r\n  margin-right: 5px;\r\n  margin-bottom:-2px;\r\n  text-align: top;\r\n  width: 0px;\r\n};\r\n\r\n.toggle-box1:checked + label:before {\r\n  content: \"\\2212\";\r\n}\r\n     .auto-style1 {\r\n         width: 63%;\r\n     }\r\n     div.content\r\n    {\r\n    font-size:5pt;\r\n    font-family:times new roman;\r\n    font-weight:bold;\r\n  \r\n\r\n    }\r\n </style>";
			try
			{
				str1 = base.SelectFieldValue("ID").ToString();
				str2 = "";
				chrArray1 = new char[] { ' ', '\t' };
				chrArray = chrArray1;
				str3 = "";
				flag = false;
				sqlText = new SqlText(string.Concat("SELECT [ModifiedDate],ModifyUser,reason FROM [NSA_PROJECT].[dbo].[DatesHistorylog] where parentID=", str1, " and Columnname='Rtr/Ckt Upgr Planned'  order by ModifiedDate desc"));
				if (sqlText.Read())
				{
					if (flag)
					{
						return;
					}
					else
					{
						flag = true;
						sqlText1 = new SqlText(string.Concat("SELECT [Full Name] FROM [NSA_PROJECT].[dbo].[NSA_USERS]  where 'AD-ENT\\' + [Ad-ENT ID] = '", sqlText.Reader.GetValue(1).ToString(), "'"));
						if (sqlText1.Read())
						{
							str2 = sqlText1.Reader.GetValue(0).ToString();
							strArrays = str2.Split(chrArray);
							str3 = string.Concat(strArrays[0][0], " ", strArrays[1]);
						}
						else
						{
							str3 = sqlText.Reader.GetValue(1).ToString();
						}
						dataField = base.Page.FindField("RtrCktUpgrPlanned");
						str4 = string.Concat(base.ControllerName, "id210001");
						str5 = string.Concat(str, "<input class=\"toggle-box1\" id=\"id1\" type=\"checkbox\" style=\"display:none\">\r\n                 <label for=\"id1\">Last update</label>");
						str5 = str5.Replace("id1", str4);
						strArrays1 = new string[] { str5, "<div style=\"color:grey; font: Helvetica 6pt;font-style:italic;\">&nbsp;Modified: ", sqlText.Reader.GetValue(0).ToString().Substring(0, 9), "<br>&nbsp;", str3, "</br>&nbsp;Reason: ", sqlText.Reader.GetValue(2).ToString(), "</div>" };
						dataField.FooterText = string.Concat(strArrays1);
						try
						{
							sqlText1.Close();
							sqlText1.Dispose(true);
						}
						catch
						{
						}
						try
						{
							sqlText.Close();
							sqlText.Dispose(true);
						}
						catch
						{
						}
					}
				}
				flag = false;
				sqlText = new SqlText(string.Concat("SELECT [ModifiedDate],ModifyUser,reason FROM [NSA_PROJECT].[dbo].[DatesHistorylog] where parentID=", str1, " and Columnname='Rtr Ckt Upgr Original Planned Date'  order by ModifiedDate desc"));
				if (sqlText.Read())
				{
					if (flag)
					{
						return;
					}
					else
					{
						flag = true;
						sqlText2 = new SqlText(string.Concat("SELECT [Full Name] FROM [NSA_PROJECT].[dbo].[NSA_USERS]  where 'AD-ENT\\' + [Ad-ENT ID] = '", sqlText.Reader.GetValue(1).ToString(), "'"));
						if (sqlText2.Read())
						{
							str2 = sqlText2.Reader.GetValue(0).ToString();
							strArrays2 = str2.Split(chrArray);
							str3 = string.Concat(strArrays2[0][0], " ", strArrays2[1]);
						}
						else
						{
							str3 = sqlText.Reader.GetValue(1).ToString();
						}
						dataField1 = base.Page.FindField("RtrCktUpgrOriginalPlannedDate");
						str6 = string.Concat(base.ControllerName, "id210002");
						str = string.Concat(str, "<input class=\"toggle-box1\" id=\" + id2 + \" type=\"checkbox\" style=\"display:none\">\r\n                <label for=\" + id2 + \">Last update</label>");
						str = str.Replace("id2", str6);
						strArrays1 = new string[] { str, "<div style=\"color:grey; font: Helvetica 6pt;font-style:italic;\">&nbsp;Modified: ", sqlText.Reader.GetValue(0).ToString().Substring(0, 9), "<br>&nbsp;", str3, "</br>&nbsp;Reason: ", sqlText.Reader.GetValue(2).ToString(), "</div>" };
						dataField1.FooterText = string.Concat(strArrays1);
						try
						{
							sqlText2.Close();
							sqlText2.Dispose(true);
						}
						catch
						{
						}
						try
						{
							sqlText.Close();
							sqlText.Dispose(true);
						}
						catch
						{
						}
					}
				}
			}
			catch
			{
			}
			str = "   <style>\r\n {\r\n  display: none;\r\n}\r\n\r\n.toggle-box1 + label {\r\n  cursor: pointer;\r\n  display: block;\r\n  font-weight:lighter;\r\n  text-decoration: underline;\r\n  line-height: 21px;\r\n  color:#3565a5;\r\n  margin-bottom: 5px;\r\n\r\n}\r\n\r\n.toggle-box1 + label + div {\r\n  display: none;\r\n  margin-bottom: -2px;\r\n}\r\n\r\n.toggle-box1:checked + label + div {\r\n  display: block;\r\n}\r\n\r\n.toggle-box1 + label:before {\r\n  background-color: #3565a5;\r\n  -webkit-border-radius: 10px;\r\n  -moz-border-radius: 10px;\r\n  border-radius: 5px;\r\n  color: #FFFFFF;\r\n  display: block;\r\n  float: right;\r\n  font-weight: bold;\r\n  height: 0px;\r\n  line-height: 20px;\r\n  margin-right: 5px;\r\n  margin-bottom:-2px;\r\n  text-align: top;\r\n  width: 0px;\r\n};\r\n\r\n.toggle-box1:checked + label:before {\r\n  content: \"\\2212\";\r\n}\r\n     .auto-style1 {\r\n         width: 63%;\r\n     }\r\n     div.content\r\n    {\r\n    font-size:5pt;\r\n    font-family:times new roman;\r\n    font-weight:bold;\r\n  \r\n\r\n    }\r\n </style>";
			try
			{
				str1 = base.SelectFieldValue("ID").ToString();
				str2 = "";
				chrArray1 = new char[] { ' ', '\t' };
				chrArray = chrArray1;
				str3 = "";
				flag = false;
				sqlText = new SqlText(string.Concat("SELECT [ModifiedDate],ModifyUser,reason FROM [NSA_PROJECT].[dbo].[DatesHistorylog] where parentID=", str1, " and Columnname='Rtr/Ckt Upgr Planned'  order by ModifiedDate desc"));
				if (sqlText.Read())
				{
					if (flag)
					{
						return;
					}
					else
					{
						flag = true;
						sqlText1 = new SqlText(string.Concat("SELECT [Full Name] FROM [NSA_PROJECT].[dbo].[NSA_USERS]  where 'AD-ENT\\' + [Ad-ENT ID] = '", sqlText.Reader.GetValue(1).ToString(), "'"));
						if (sqlText1.Read())
						{
							str2 = sqlText1.Reader.GetValue(0).ToString();
							strArrays = str2.Split(chrArray);
							str3 = string.Concat(strArrays[0][0], " ", strArrays[1]);
						}
						else
						{
							str3 = sqlText.Reader.GetValue(1).ToString();
						}
						dataField = base.Page.FindField("RtrCktUpgrPlanned");
						str4 = string.Concat(base.ControllerName, "id210001");
						str5 = string.Concat(str, "<input class=\"toggle-box1\" id=\"id1\" type=\"checkbox\" style=\"display:none\">\r\n                 <label for=\"id1\">Last update</label>");
						str5 = str5.Replace("id1", str4);
						strArrays1 = new string[] { str5, "<div style=\"color:grey; font: Helvetica 6pt;font-style:italic;\">&nbsp;Modified: ", sqlText.Reader.GetValue(0).ToString().Substring(0, 9), "<br>&nbsp;", str3, "</br>&nbsp;Reason: ", sqlText.Reader.GetValue(2).ToString(), "</div>" };
						dataField.FooterText = string.Concat(strArrays1);
						try
						{
							sqlText1.Close();
							sqlText1.Dispose(true);
						}
						catch
						{
						}
						try
						{
							sqlText.Close();
							sqlText.Dispose(true);
						}
						catch
						{
						}
					}
				}
				flag = false;
				sqlText = new SqlText(string.Concat("SELECT [ModifiedDate],ModifyUser,reason FROM [NSA_PROJECT].[dbo].[DatesHistorylog] where parentID=", str1, " and Columnname='Rtr Ckt Upgr Original Planned Date'  order by ModifiedDate desc"));
				if (sqlText.Read())
				{
					if (flag)
					{
						return;
					}
					else
					{
						flag = true;
						sqlText2 = new SqlText(string.Concat("SELECT [Full Name] FROM [NSA_PROJECT].[dbo].[NSA_USERS]  where 'AD-ENT\\' + [Ad-ENT ID] = '", sqlText.Reader.GetValue(1).ToString(), "'"));
						if (sqlText2.Read())
						{
							str2 = sqlText2.Reader.GetValue(0).ToString();
							strArrays2 = str2.Split(chrArray);
							str3 = string.Concat(strArrays2[0][0], " ", strArrays2[1]);
						}
						else
						{
							str3 = sqlText.Reader.GetValue(1).ToString();
						}
						dataField1 = base.Page.FindField("RtrCktUpgrOriginalPlannedDate");
						str6 = string.Concat(base.ControllerName, "id210002");
						str = string.Concat(str, "<input class=\"toggle-box1\" id=\" + id2 + \" type=\"checkbox\"  style=\"display:none\">\r\n                <label for=\" + id2 + \">Last update</label>");
						str = str.Replace("id2", str6);
						strArrays1 = new string[] { str, "<div style=\"color:grey; font: Helvetica 6pt;font-style:italic;\">&nbsp;Modified: ", sqlText.Reader.GetValue(0).ToString().Substring(0, 9), "<br>&nbsp;", str3, "</br>&nbsp;Reason: ", sqlText.Reader.GetValue(2).ToString(), "</div>" };
						dataField1.FooterText = string.Concat(strArrays1);
						try
						{
							sqlText2.Close();
							sqlText2.Dispose(true);
						}
						catch
						{
						}
						try
						{
							sqlText.Close();
							sqlText.Dispose(true);
						}
						catch
						{
						}
					}
				}
			}
			catch
			{
			}
		}

		[ControllerAction("ctlEquipmentMgmt", "Select", ActionPhase.After)]
		[ControllerAction("ctlIPTBranchDiscovery", "Select", ActionPhase.After)]
		[ControllerAction("ctlSiteReadinessEUCCoordination", "Select", ActionPhase.After)]
		public void setconvfooter()
		{
			string[] strArrays1;
			string str = "   <style>\r\n.toggle-box1 {\r\n  display: none;\r\n}\r\n\r\n.toggle-box1 + label {\r\n  cursor: pointer;\r\n  display: block;\r\n  font-weight:lighter;\r\n  text-decoration: underline;\r\n  line-height: 21px;\r\n  color:#3565a5;\r\n  margin-bottom: 5px;\r\n\r\n}\r\n\r\n.toggle-box1 + label + div {\r\n  display: none;\r\n  margin-bottom: -2px;\r\n}\r\n\r\n.toggle-box1:checked + label + div {\r\n  display: block;\r\n}\r\n\r\n.toggle-box1 + label:before {\r\n  background-color: #3565a5;\r\n  -webkit-border-radius: 10px;\r\n  -moz-border-radius: 10px;\r\n  border-radius: 5px;\r\n  color: #FFFFFF;\r\n  display: block;\r\n  float: right;\r\n  font-weight: bold;\r\n  height: 0px;\r\n  line-height: 20px;\r\n  margin-right: 5px;\r\n  margin-bottom:-2px;\r\n  text-align: top;\r\n  width: 0px;\r\n};\r\n\r\n.toggle-box1:checked + label:before {\r\n  content: \"\\2212\";\r\n}\r\n     .auto-style1 {\r\n         width: 63%;\r\n     }\r\n     div.content\r\n    {\r\n    font-size:5pt;\r\n    font-family:times new roman;\r\n    font-weight:bold;\r\n  \r\n\r\n    }\r\n </style>";
			try
			{
				string str1 = base.SelectFieldValue("ID").ToString();
				string str2 = "";
				char[] chrArray = new char[] { ' ', '\t' };
				string str3 = "";
				bool flag = false;
				SqlText sqlText = new SqlText(string.Concat("SELECT [ModifiedDate],ModifyUser,reason FROM [NSA_PROJECT].[dbo].[DatesHistorylog] where parentID=", str1, " and Columnname='IPT Conversion Date Planned'  order by ModifiedDate desc"));
				if (sqlText.Read())
				{
					if (flag)
					{
						return;
					}
					else
					{
						flag = true;
						SqlText sqlText1 = new SqlText(string.Concat("SELECT [Full Name] FROM [NSA_PROJECT].[dbo].[NSA_USERS]  where 'AD-ENT\\' + [Ad-ENT ID] = '", sqlText.Reader.GetValue(1).ToString(), "'"));
						if (sqlText1.Read())
						{
							str2 = sqlText1.Reader.GetValue(0).ToString();
							string[] strArrays = str2.Split(chrArray);
							str3 = string.Concat(strArrays[0][0], " ", strArrays[1]);
						}
						else
						{
							str3 = sqlText.Reader.GetValue(1).ToString();
						}
						DataField dataField = base.Page.FindField("IPTConversionDatePlanned");
						string str4 = string.Concat(base.ControllerName, "mid210001");
						string str5 = string.Concat(str, "<input class=\"toggle-box1\" id=\"id1\" type=\"checkbox\" style=\"display:none\">\r\n                 <label for=\"id1\">Last update</label>");
						str5 = str5.Replace("id1", str4);
						strArrays1 = new string[] { str5, "<div style=\"color:grey; font: Helvetica 6pt;font-style:italic;\">&nbsp;Modified: ", sqlText.Reader.GetValue(0).ToString().Substring(0, 9), "<br>&nbsp;", str3, "</br>&nbsp;Reason: ", sqlText.Reader.GetValue(2).ToString(), "</div>" };
						dataField.FooterText = string.Concat(strArrays1);
						try
						{
							sqlText1.Close();
							sqlText1.Dispose(true);
						}
						catch
						{
						}
						try
						{
							sqlText.Close();
							sqlText.Dispose(true);
						}
						catch
						{
						}
					}
				}
				flag = false;
				sqlText = new SqlText(string.Concat("SELECT [ModifiedDate],ModifyUser,reason FROM [NSA_PROJECT].[dbo].[DatesHistorylog] where parentID=", str1, " and Columnname='IPT Conversion Original Date Planned'  order by ModifiedDate desc"));
				if (sqlText.Read())
				{
					if (flag)
					{
						return;
					}
					else
					{
						flag = true;
						SqlText sqlText2 = new SqlText(string.Concat("SELECT [Full Name] FROM [NSA_PROJECT].[dbo].[NSA_USERS]  where 'AD-ENT\\' + [Ad-ENT ID] = '", sqlText.Reader.GetValue(1).ToString(), "'"));
						if (sqlText2.Read())
						{
							str2 = sqlText2.Reader.GetValue(0).ToString();
							string[] strArrays2 = str2.Split(chrArray);
							str3 = string.Concat(strArrays2[0][0], " ", strArrays2[1]);
						}
						else
						{
							str3 = sqlText.Reader.GetValue(1).ToString();
						}
						DataField dataField1 = base.Page.FindField("IPTConversionOriginalDatePlanned");
						string str6 = string.Concat(base.ControllerName, "jid210002");
						str = string.Concat(str, "<input class=\"toggle-box1\" id=\" + id2 + \" type=\"checkbox\" style=\"display:none\">\r\n                <label for=\" + id2 + \">Last update</label>");
						str = str.Replace("id2", str6);
						strArrays1 = new string[] { str, "<div style=\"color:grey; font: Helvetica 6pt;font-style:italic;\">&nbsp;Modified: ", sqlText.Reader.GetValue(0).ToString().Substring(0, 9), "<br>&nbsp;", str3, "</br>&nbsp;Reason: ", sqlText.Reader.GetValue(2).ToString(), "</div>" };
						dataField1.FooterText = string.Concat(strArrays1);
						try
						{
							sqlText2.Close();
							sqlText2.Dispose(true);
						}
						catch
						{
						}
						try
						{
							sqlText.Close();
							sqlText.Dispose(true);
						}
						catch
						{
						}
					}
				}
			}
			catch
			{
			}
		}

		[ControllerAction("NSA_Address_Info", "Calculate", "Issue")]
		[RowBuilder("NSA_Address_Info", "grid1", RowKind.Existing)]
		private void setIssueflag()
		{
			int Id = Convert.ToInt32(base.SelectFieldValue("ID"));
			SqlText findissue = new SqlText(string.Concat("select  Id,[ISSUEStatus] from  Issues where [ISSUEStatus] !='Resolved' and id=", Id.ToString()));
			if (findissue.Read())
			{
				base.UpdateFieldValue("Issue", true);
			}
			try
			{
				findissue.Close();
				findissue.Dispose(true);
			}
			catch
			{
			}
		}

		[ControllerAction("CPG_IPT", "Calculate", "Issue")]
		[RowBuilder("CPG_IPT", "grd1", RowKind.Existing)]
		private void setIssueflagIssueCPG_IPT()
		{
			int Id = Convert.ToInt32(base.SelectFieldValue("ID"));
			SqlText findissue = new SqlText(string.Concat("select  Id,[ISSUEStatus] from  Issues where [ISSUEStatus] !='Resolved' and id=", Id.ToString()));
			if (findissue.Read())
			{
				base.UpdateFieldValue("Issue", true);
			}
			try
			{
				findissue.Close();
				findissue.Dispose(true);
			}
			catch
			{
			}
		}

		[ControllerAction("ctlHardwareview", "Calculate", "Issue")]
		[RowBuilder("ctlHardwareview", "grid1", RowKind.Existing)]
		private void setIssueflagIssuectlHardwareview()
		{
			int Id = Convert.ToInt32(base.SelectFieldValue("ID"));
			SqlText findissue = new SqlText(string.Concat("select  Id,[ISSUEStatus] from  Issues where [ISSUEStatus] !='Resolved' and id=", Id.ToString()));
			if (findissue.Read())
			{
				base.UpdateFieldValue("Issue", true);
			}
			try
			{
				findissue.Close();
				findissue.Dispose(true);
			}
			catch
			{
			}
		}

		[ControllerAction("ctlIssueView", "Calculate", "Issue")]
		[RowBuilder("ctlIssueView", "grid1", RowKind.Existing)]
		private void setIssueflagIssueView()
		{
			int Id = Convert.ToInt32(base.SelectFieldValue("ID"));
			SqlText findissue = new SqlText(string.Concat("select  Id,[ISSUEStatus] from  Issues where [ISSUEStatus] !='Resolved' and id=", Id.ToString()));
			if (findissue.Read())
			{
				base.UpdateFieldValue("Issue", true);
			}
			try
			{
				findissue.Close();
				findissue.Dispose(true);
			}
			catch
			{
			}
		}

		[ControllerAction("CPD_WLAN", "Calculate", "Issue")]
		[RowBuilder("CPD_WLAN", "grid1", RowKind.Existing)]
		private void setIssueflagIssueViewCPD_WLAN()
		{
			int Id = Convert.ToInt32(base.SelectFieldValue("ID"));
			SqlText findissue = new SqlText(string.Concat("select  Id,[ISSUEStatus] from  Issues where [ISSUEStatus] !='Resolved' and id=", Id.ToString()));
			if (findissue.Read())
			{
				base.UpdateFieldValue("Issue", true);
			}
			try
			{
				findissue.Close();
				findissue.Dispose(true);
			}
			catch
			{
			}
		}

		[ControllerAction("CPG_SITE_READINESS", "Calculate", "Issue")]
		[RowBuilder("CPG_SITE_READINESS", "grid1", RowKind.Existing)]
		private void setIssueflagIssueViewCPG_SITE_READINESS()
		{
			int Id = Convert.ToInt32(base.SelectFieldValue("ID"));
			SqlText findissue = new SqlText(string.Concat("select  Id,[ISSUEStatus] from  Issues where [ISSUEStatus] !='Resolved' and id=", Id.ToString()));
			if (findissue.Read())
			{
				base.UpdateFieldValue("Issue", true);
			}
			try
			{
				findissue.Close();
				findissue.Dispose(true);
			}
			catch
			{
			}
		}

		[ControllerAction("ctlWLANFloorplanIssues", "Calculate", "Issue")]
		[RowBuilder("ctlWLANFloorplanIssues", "grid1", RowKind.Existing)]
		private void setIssueflagIssueViewctlWLANFloorplanIssues()
		{
			int Id = Convert.ToInt32(base.SelectFieldValue("ID"));
			SqlText findissue = new SqlText(string.Concat("select  Id,[ISSUEStatus] from  Issues where [ISSUEStatus] !='Resolved' and id=", Id.ToString()));
			if (findissue.Read())
			{
				base.UpdateFieldValue("Issue", true);
			}
			try
			{
				findissue.Close();
				findissue.Dispose(true);
			}
			catch
			{
			}
		}

		[ControllerAction("NSA_Address_Info2", "Calculate", "Issue")]
		[RowBuilder("NSA_Address_Info2", "projectinfo", RowKind.Existing)]
		private void setIssueflagIssueViewNSA_Address_Info2()
		{
			int Id = Convert.ToInt32(base.SelectFieldValue("ID"));
			SqlText findissue = new SqlText(string.Concat("select  Id,[ISSUEStatus] from  Issues where [ISSUEStatus] !='Resolved' and id=", Id.ToString()));
			if (findissue.Read())
			{
				base.UpdateFieldValue("Issue", true);
			}
			try
			{
				findissue.Close();
				findissue.Dispose(true);
			}
			catch
			{
			}
		}

		[ControllerAction("NSA_Address_Info3", "Calculate", "Issue")]
		[RowBuilder("NSA_Address_Info3", "grid1", RowKind.Existing)]
		private void setIssueflagIssueViewNSA_Address_Info3()
		{
			int Id = Convert.ToInt32(base.SelectFieldValue("ID"));
			SqlText findissue = new SqlText(string.Concat("select  Id,[ISSUEStatus] from  Issues where [ISSUEStatus] !='Resolved' and id=", Id.ToString()));
			if (findissue.Read())
			{
				base.UpdateFieldValue("Issue", true);
			}
			try
			{
				findissue.Close();
				findissue.Dispose(true);
			}
			catch
			{
			}
		}

		[ControllerAction("ctlIPTProjectInformation", "Calculate", "Issue")]
		[RowBuilder("ctlIPTProjectInformation", "grid1", RowKind.Existing)]
		private void setIssueflagIssueViewNSA_Address_Info4()
		{
			int Id = Convert.ToInt32(base.SelectFieldValue("ID"));
			SqlText findissue = new SqlText(string.Concat("select  Id,[ISSUEStatus] from  Issues where [ISSUEStatus] !='Resolved' and id=", Id.ToString()));
			if (findissue.Read())
			{
				base.UpdateFieldValue("Issue", true);
			}
			try
			{
				findissue.Close();
				findissue.Dispose(true);
			}
			catch
			{
			}
		}

		[ControllerAction("ctlIPTBranchDiscovery", "Select", ActionPhase.After)]
		public void setTTfooter()
		{
			string[] strArrays1;
			string str = "   <style>\r\n.toggle-box1 {\r\n  display: none;\r\n}\r\n\r\n.toggle-box1 + label {\r\n  cursor: pointer;\r\n  display: block;\r\n  font-weight:lighter;\r\n  text-decoration: underline;\r\n  line-height: 21px;\r\n  color:#3565a5;\r\n  margin-bottom: 5px;\r\n\r\n}\r\n\r\n.toggle-box1 + label + div {\r\n  display: none;\r\n  margin-bottom: -2px;\r\n}\r\n\r\n.toggle-box1:checked + label + div {\r\n  display: block;\r\n}\r\n\r\n.toggle-box1 + label:before {\r\n  background-color: #3565a5;\r\n  -webkit-border-radius: 10px;\r\n  -moz-border-radius: 10px;\r\n  border-radius: 5px;\r\n  color: #FFFFFF;\r\n  display: block;\r\n  float: right;\r\n  font-weight: bold;\r\n  height: 0px;\r\n  line-height: 20px;\r\n  margin-right: 5px;\r\n  margin-bottom:-2px;\r\n  text-align: top;\r\n  width: 0px;\r\n};\r\n\r\n.toggle-box1:checked + label:before {\r\n  content: \"\\2212\";\r\n}\r\n     .auto-style1 {\r\n         width: 63%;\r\n     }\r\n     div.content\r\n    {\r\n    font-size:5pt;\r\n    font-family:times new roman;\r\n    font-weight:bold;\r\n  \r\n\r\n    }\r\n </style>";
			try
			{
				string str1 = base.SelectFieldValue("ID").ToString();
				string str2 = "";
				char[] chrArray = new char[] { ' ', '\t' };
				string str3 = "";
				bool flag = false;
				SqlText sqlText = new SqlText(string.Concat("SELECT [ModifiedDate],ModifyUser,reason FROM [NSA_PROJECT].[dbo].[DatesHistorylog] where parentID=", str1, " and Columnname='IPT T&T Date'  order by ModifiedDate desc"));
				if (sqlText.Read())
				{
					if (flag)
					{
						return;
					}
					else
					{
						flag = true;
						SqlText sqlText1 = new SqlText(string.Concat("SELECT [Full Name] FROM [NSA_PROJECT].[dbo].[NSA_USERS]  where 'AD-ENT\\' + [Ad-ENT ID] = '", sqlText.Reader.GetValue(1).ToString(), "'"));
						if (sqlText1.Read())
						{
							str2 = sqlText1.Reader.GetValue(0).ToString();
							string[] strArrays = str2.Split(chrArray);
							str3 = string.Concat(strArrays[0][0], " ", strArrays[1]);
						}
						else
						{
							str3 = sqlText.Reader.GetValue(1).ToString();
						}
						DataField dataField = base.Page.FindField("IPTTTDate");
						string str4 = string.Concat(str, "<input class=\"toggle-box1\" id=\"hz22222eaderMain\" type=\"checkbox\" style=\"display:none\">\r\n                 <label for=\"hz22222eaderMain\">Last update</label>");
						str4 = str4.Replace("hz22222eaderMain", string.Concat(base.ControllerName, "hz22222eaderMain"));
						strArrays1 = new string[] { str4, "<div style=\"color:grey; font: Helvetica 6pt;font-style:italic;\">&nbsp;Modified: ", sqlText.Reader.GetValue(0).ToString().Substring(0, 9), "<br>&nbsp;", str3, "</br>&nbsp;Reason: ", sqlText.Reader.GetValue(2).ToString(), "</div>" };
						dataField.FooterText = string.Concat(strArrays1);
						try
						{
							sqlText1.Close();
							sqlText1.Dispose(true);
						}
						catch
						{
						}
						try
						{
							sqlText.Close();
							sqlText.Dispose(true);
						}
						catch
						{
						}
					}
				}
				flag = false;
				sqlText = new SqlText(string.Concat("SELECT [ModifiedDate],ModifyUser,reason FROM [NSA_PROJECT].[dbo].[DatesHistorylog] where parentID=", str1, " and Columnname='IPT T&T Original Date'  order by ModifiedDate desc"));
				if (sqlText.Read())
				{
					if (flag)
					{
						return;
					}
					else
					{
						flag = true;
						SqlText sqlText2 = new SqlText(string.Concat("SELECT [Full Name] FROM [NSA_PROJECT].[dbo].[NSA_USERS]  where 'AD-ENT\\' + [Ad-ENT ID] = '", sqlText.Reader.GetValue(1).ToString(), "'"));
						if (sqlText2.Read())
						{
							str2 = sqlText2.Reader.GetValue(0).ToString();
							string[] strArrays2 = str2.Split(chrArray);
							str3 = string.Concat(strArrays2[0][0], " ", strArrays2[1]);
						}
						else
						{
							str3 = sqlText.Reader.GetValue(1).ToString();
						}
						DataField dataField1 = base.Page.FindField("IPTTTOriginalDate");
						str = string.Concat(str, "<input class=\"toggle-box1\" id=\"hI2222eaderMain\" type=\"checkbox\" style=\"display:none\">\r\n        <label for=\"hI2222eaderMain\">Last update</label>");
						str = str.Replace("hI2222eaderMain", string.Concat(base.ControllerName, "hI2222eaderMain"));
						strArrays1 = new string[] { str, "<div style=\"color:grey; font: Helvetica 6pt;font-style:italic;\">&nbsp;Modified: ", sqlText.Reader.GetValue(0).ToString().Substring(0, 9), "<br>&nbsp;", str3, "</br>&nbsp;Reason: ", sqlText.Reader.GetValue(2).ToString(), "</div>" };
						dataField1.FooterText = string.Concat(strArrays1);
						try
						{
							sqlText2.Close();
							sqlText2.Dispose(true);
						}
						catch
						{
						}
						try
						{
							sqlText.Close();
							sqlText.Dispose(true);
						}
						catch
						{
						}
					}
				}
			}
			catch
			{
			}
		}

		[ControllerAction("ctlBOM", "Select", ActionPhase.After)]
		[ControllerAction("ctlInstalledVendors", "Select", ActionPhase.After)]
		[ControllerAction("ctlWLANProjectInformation", "Select", ActionPhase.After)]
		[ControllerAction("NSA_Address_Info2", "Select", ActionPhase.After)]
		public void setWLANfooter()
		{
			string[] strArrays1;
			string str = "   <style>\r\n.toggle-box1 {\r\n  display: none;\r\n}\r\n\r\n.toggle-box1 + label {\r\n  cursor: pointer;\r\n  display: block;\r\n  font-weight:lighter;\r\n  text-decoration: underline;\r\n  line-height: 21px;\r\n  color:#3565a5;\r\n  margin-bottom: 5px;\r\n\r\n}\r\n\r\n.toggle-box1 + label + div {\r\n  display: none;\r\n  margin-bottom: -2px;\r\n}\r\n\r\n.toggle-box1:checked + label + div {\r\n  display: block;\r\n}\r\n\r\n.toggle-box1 + label:before {\r\n  background-color: #3565a5;\r\n  -webkit-border-radius: 10px;\r\n  -moz-border-radius: 10px;\r\n  border-radius: 5px;\r\n  color: #FFFFFF;\r\n  display: block;\r\n  float: right;\r\n  font-weight: bold;\r\n  height: 0px;\r\n  line-height: 20px;\r\n  margin-right: 5px;\r\n  margin-bottom:-2px;\r\n  text-align: top;\r\n  width: 0px;\r\n};\r\n\r\n.toggle-box1:checked + label:before {\r\n  content: \"\\2212\";\r\n}\r\n     .auto-style1 {\r\n         width: 63%;\r\n     }\r\n     div.content\r\n    {\r\n    font-size:5pt;\r\n    font-family:times new roman;\r\n    font-weight:bold;\r\n  \r\n\r\n    }\r\n </style>";
			try
			{
				string str1 = base.SelectFieldValue("ID").ToString();
				string str2 = "";
				char[] chrArray = new char[] { ' ', '\t' };
				string str3 = "";
				bool flag = false;
				SqlText sqlText = new SqlText(string.Concat("SELECT [ModifiedDate],ModifyUser,reason FROM [NSA_PROJECT].[dbo].[DatesHistorylog] where parentID=", str1, " and Columnname='WLAN PLANNED INSTALL DATE'  order by ModifiedDate desc"));
				if (sqlText.Read())
				{
					if (flag)
					{
						return;
					}
					else
					{
						flag = true;
						SqlText sqlText1 = new SqlText(string.Concat("SELECT [Full Name] FROM [NSA_PROJECT].[dbo].[NSA_USERS]  where 'AD-ENT\\' + [Ad-ENT ID] = '", sqlText.Reader.GetValue(1).ToString(), "'"));
						if (sqlText1.Read())
						{
							str2 = sqlText1.Reader.GetValue(0).ToString();
							string[] strArrays = str2.Split(chrArray);
							str3 = string.Concat(strArrays[0][0], " ", strArrays[1]);
						}
						else
						{
							str3 = sqlText.Reader.GetValue(1).ToString();
						}
						DataField dataField = base.Page.FindField("WLANInstallPlannedDate");
						string str4 = string.Concat(str, "<input class=\"toggle-box1\" id=\"h22222eaderMain\" type=\"checkbox\" style=\"display:none\">\r\n                 <label for=\"h22222eaderMain\">Last update</label>");
						str4 = str4.Replace("h22222eaderMain", string.Concat(base.ControllerName, "h22222eaderMain"));
						strArrays1 = new string[] { str4, "<div style=\"color:grey; font: Helvetica 6pt;font-style:italic;\">&nbsp;Modified: ", sqlText.Reader.GetValue(0).ToString().Substring(0, 9), "<br>&nbsp;", str3, "</br>&nbsp;Reason: ", sqlText.Reader.GetValue(2).ToString(), "</div>" };
						dataField.FooterText = string.Concat(strArrays1);
						try
						{
							sqlText.Close();
							sqlText.Dispose(true);
						}
						catch
						{
						}
						try
						{
							sqlText1.Close();
							sqlText1.Dispose(true);
						}
						catch
						{
						}
					}
				}
				flag = false;
				sqlText = new SqlText(string.Concat("SELECT [ModifiedDate],ModifyUser,reason FROM [NSA_PROJECT].[dbo].[DatesHistorylog] where parentID=", str1, " and Columnname='Site Visit - Reschedule'  order by ModifiedDate desc"));
				if (sqlText.Read())
				{
					if (flag)
					{
						return;
					}
					else
					{
						flag = true;
						SqlText sqlText2 = new SqlText(string.Concat("SELECT [Full Name] FROM [NSA_PROJECT].[dbo].[NSA_USERS]  where 'AD-ENT\\' + [Ad-ENT ID] = '", sqlText.Reader.GetValue(1).ToString(), "'"));
						if (sqlText2.Read())
						{
							str2 = sqlText2.Reader.GetValue(0).ToString();
							string[] strArrays2 = str2.Split(chrArray);
							str3 = string.Concat(strArrays2[0][0], " ", strArrays2[1]);
						}
						else
						{
							str3 = sqlText.Reader.GetValue(1).ToString();
						}
						DataField dataField1 = base.Page.FindField("SiteVisitReschedule");
						str = string.Concat(str, "<input class=\"toggle-box1\" id=\"h2222eaderMain\" type=\"checkbox\" style=\"display:none\">\r\n        <label for=\"h2222eaderMain\">Last update</label>");
						str = str.Replace("h2222eaderMain", string.Concat(base.ControllerName, "h2222eaderMain"));
						strArrays1 = new string[] { str, "<div style=\"color:grey; font: Helvetica 6pt;font-style:italic;\">&nbsp;Modified: ", sqlText.Reader.GetValue(0).ToString().Substring(0, 9), "<br>&nbsp;", str3, "</br>&nbsp;Reason: ", sqlText.Reader.GetValue(2).ToString(), "</div>" };
						dataField1.FooterText = string.Concat(strArrays1);
						try
						{
							sqlText.Close();
							sqlText.Dispose(true);
						}
						catch
						{
						}
						try
						{
							sqlText2.Close();
							sqlText2.Dispose(true);
						}
						catch
						{
						}
					}
				}
			}
			catch
			{
			}
		}

		[ControllerAction("NSA_Address_Info", "Custom", "SiteReadinessforIPT")]
		public void SiteReadinessforIPT1()
		{
			FilterValue[] filterValue = new FilterValue[1];
			object[] objArray = new object[] { "N", "Pilot" };
			filterValue[0] = new FilterValue("IPTYNexisting", RowFilterOperation.DoesNotInclude, objArray);
			base.AssignFilter(filterValue);
			base.Result.Refresh();
		}

		public override bool SupportsVirtualization(string controllerName)
		{
			return true;
		}

		public static DateTime UnixTimestampToDateTime(double unixTime)
		{
			DateTime unixStart = new DateTime(1970, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc);
			long unixTimeStampInTicks = (long)(unixTime * 10000000);
			return new DateTime(unixStart.Ticks + unixTimeStampInTicks);
		}

		[RowBuilder("ctlIssue", "editForm1", RowKind.Existing)]
		private void updateissuenote()
		{
			string[] localar;
			string shortlocaln;
			int i;
			string[] name;
			string userName = "";
			string snote = "";
			string tms = "";
			string localn = "";
			string signature = "";
			string sname = null;
			char[] whitespace = new char[] { ' ', '\t' };
			try
			{
				SqlText finduser = new SqlText(string.Concat("SELECT [Full Name] FROM [NSA_PROJECT].[dbo].[NSA_USERS]  where 'AD-ENT\\' + [Ad-ENT ID] = '", base.Context.User.Identity.Name, "'"));
				if (finduser.Read())
				{
					sname = finduser.Reader.GetValue(0).ToString();
				}
				try
				{
					finduser.Close();
				}
				catch
				{
				}
				snote = base.SelectFieldValue("Issuenotes").ToString();
				tms = DateTime.Now.ToShortDateString();
				localn = TimeZone.CurrentTimeZone.StandardName;
				localar = localn.Split(whitespace);
				shortlocaln = "";
				for (i = 0; i < (int)localar.Length; i++)
				{
					shortlocaln = string.Concat(shortlocaln, localar[i].ToString()[0]);
				}
				string[] snamear = sname.Split(whitespace);
				if ((sname == null ? false : !(sname.Trim() == "")))
				{
					object[] objArray = new object[] { "[", snamear[0][0], " ", snamear[1], " <", tms, ">]\r" };
					signature = string.Concat(objArray);
				}
				else
				{
					name = new string[] { "[", base.Context.User.Identity.Name, " <", tms, ">]\r" };
					signature = string.Concat(name);
				}
				base.Result.ExecuteOnClient("this._focus('Issuenotes')");
				snote = string.Concat(signature, snote);
				base.UpdateFieldValue("Issuenotes", snote);
			}
			catch
			{
				localar = localn.Split(whitespace);
				shortlocaln = "";
				for (i = 0; i < (int)localar.Length; i++)
				{
					shortlocaln = string.Concat(shortlocaln, localar[i].ToString()[0]);
				}
				signature = "";
				snote = "";
				snote = base.SelectFieldValue("Issuenotes").ToString();
				name = new string[] { "[", userName, " <", tms, ":", localn, ">]\r" };
				signature = string.Concat(name);
				snote = string.Concat(signature, snote);
				base.UpdateFieldValue("Issuenotes", snote);
			}
		}

		[ControllerAction("ctlUserViewFields", "Select", ActionPhase.After)]
		public void userViewFieldSelected()
		{
			string suser = "";
			suser = base.Context.User.Identity.Name;
			if (base.SelectFieldValue("VIEWID") != null)
			{
				string viewid = base.SelectFieldValue("VIEWID").ToString();
				SqlText sql = new SqlText(string.Concat("Update NSA_View set ViewSelected=0 where useridentity='", suser, "'"));
				sql.ExecuteNonQuery();
				sql.Close();
				sql = new SqlText(string.Concat("Update NSA_View set ViewSelected=1 where viewid=", viewid));
				sql.ExecuteNonQuery();
				sql.Close();
			}
			else
			{
				SqlText sql1 = new SqlText(string.Concat("Update NSA_View set ViewSelected=0 where useridentity='", suser, "'"));
				sql1.ExecuteNonQuery();
				sql1.Close();
			}
		}

		public override void VirtualizeController(string controllerName, XPathNavigator navigator, XmlNamespaceManager resolver)
		{
			string viewid;
			string s;
			string sdate;
			long sd1;
			DateTime convdt;
			string srep;
			base.Navigator = navigator;
			base.Resolver = resolver;
			string suser = "";
            if (controllerName == "NSA_REQUEST_STAGE")
            {
                if (!(base.Context.Session["Session_INVENTORY_TYPE"] == null ? true : !(base.Context.Session["Session_INVENTORY_TYPE"].ToString() == "LINE")))
                {
                    base.NodeSet().SelectView("grid1").SetFilter("typename = 'LINE'");
                }
                else if ((base.Context.Session["Session_INVENTORY_TYPE"] == null ? false : base.Context.Session["Session_INVENTORY_TYPE"].ToString() == "CIRCUIT"))
                {
                    base.NodeSet().SelectView("grid1").SetFilter("typename = 'CIRCUIT'");
                    if (!(base.Context.Session["Session_INVENTORY_DATA"] == null))
                    {
                        bool b = false;
                        try
                        {
                            if (navigator.SelectSingleNode("//c:command[@id='command1']/c:text", resolver).InnerXml.IndexOf("DATANETWORK") == -1) b = false;
                            else b = true;
                        }
                        catch { b = false; }
                        if (b)  base.NodeSet().SelectView("grid1").SetFilter("typename = 'CIRCUIT'" + " and" +" DATANETWORK = '" + base.Context.Session["Session_INVENTORY_DATA"].ToString() + "'");
                    }
                }
                
              
            }
            else if (!(controllerName == "NSA_ORDER_STAGE"))
            {
			suser = base.Context.User.Identity.Name;
			SqlText findrole = new SqlText(string.Concat("SELECT [NSA_Role] FROM [NSA_PROJECT].[dbo].[NSA_USERS]  where 'AD-ENT\\' + [Ad-ENT ID] = '", suser, "'"));
			string srole = "";
			if (findrole.Read())
			{
				srole = findrole.Reader.GetValue(0).ToString();
			}
			try
			{
				findrole.Close();
			}
			catch
			{
			}
			if (controllerName == "ctlUserView")
			{
				if (!(srole != "admin"))
				{
					base.NodeSet().SelectView("grid1").SelectField("viewispublic").SetReadOnly(false);
				}
				else
				{
					base.NodeSet().SelectView("grid1").SelectField("viewispublic").SetReadOnly(true);
				}
			}
			else if (controllerName == "ctlAllItems")
			{
				base.Navigator = navigator;
				base.Resolver = resolver;
				SqlText sql = new SqlText(string.Concat("Select viewid,ViewCondition,viewname from [NSA_View] where ViewSelected=1 and useridentity='", suser, "' or viewispublic=1"));
				string scondition = "";
				viewid = "";
				string sviewname = "";
				if (sql.Read())
				{
					viewid = sql.Reader.GetValue(0).ToString();
					scondition = sql.Reader.GetValue(1).ToString();
					sviewname = sql.Reader.GetValue(2).ToString();
				}
				sql.Close();
				string[] strArrays = new string[] { "~^" };
				string[] endofline = strArrays;
				string[] condition = new string[0];
				if ((scondition == null ? false : scondition.Trim().Length > 0))
				{
					condition = scondition.Split(endofline, StringSplitOptions.None);
				}
				base.NodeSet().SelectView("grid1").SetLabel(string.Concat("Custom View - ", sviewname));
				sql = new SqlText(string.Concat("Select FieldID,Visible,OrderBy,sequence from NSA_View_Fields where ViewId=", viewid, " order by sequence asc"));
				string fieldname = "";
				string orderby = "";
				string visible = "";
				string sequence = "";
				s = "";
				bool bfoundone = false;
				while (sql.Read())
				{
					fieldname = sql.Reader.GetValue(0).ToString();
					visible = sql.Reader.GetValue(1).ToString();
					orderby = sql.Reader.GetValue(2).ToString();
					sequence = sql.Reader.GetValue(3).ToString();
					if ((fieldname.Contains("Workstream") || fieldname.Contains("IssueNotes") || fieldname.Contains("IssueOwner") || fieldname.Contains("IssueStart") || fieldname.Contains("IssueType") || fieldname.Contains("IssueEnd") || fieldname.Contains("IssuePriority") || fieldname.Contains("IssueStatus") ? true : fieldname.Contains("IssueNumber")))
					{
						bfoundone = true;
					}
					try
					{
						if ((orderby == null ? false : orderby.Length > 0))
						{
							strArrays = new string[] { s, fieldname, " ", orderby, "," };
							s = string.Concat(strArrays);
							orderby = "";
						}
						try
						{
							ControllerNodeSet nd22 = base.NodeSet().SelectView("grid1").CreateDataField(fieldname);
							try
							{
								if (fieldname.Contains("comment"))
								{
									nd22.SetRows(7);
								}
							}
							catch
							{
							}
						}
						catch
						{
						}
					}
					catch
					{
					}
				}
				if (s.Trim().Length > 0)
				{
					s = s.Substring(0, s.Length - 1);
					base.NodeSet().SelectView("grid1").SetSortExpression(s);
				}
				sql.Close();
				if (bfoundone)
				{
					string sqq = navigator.SelectSingleNode("//c:command[@id='command2']/c:text", resolver).InnerXml;
					sqq = sqq.Replace("&amp;", "&");
					navigator.SelectSingleNode("//c:command[@id='command1']/c:text", resolver).SetValue(sqq);
				}
				else
				{
					try
					{
						navigator.SelectSingleNode("//c:fields/c:field[@name='IssueNotes']", resolver).DeleteSelf();
						navigator.SelectSingleNode("//c:fields/c:field[@name='IssueOwner']", resolver).DeleteSelf();
						navigator.SelectSingleNode("//c:fields/c:field[@name='IssueStart']", resolver).DeleteSelf();
						navigator.SelectSingleNode("//c:fields/c:field[@name='IssueType']", resolver).DeleteSelf();
						navigator.SelectSingleNode("//c:fields/c:field[@name='IssueEnd']", resolver).DeleteSelf();
						navigator.SelectSingleNode("//c:fields/c:field[@name='IssuePriority']", resolver).DeleteSelf();
						navigator.SelectSingleNode("//c:fields/c:field[@name='IssueStatus']", resolver).DeleteSelf();
						navigator.SelectSingleNode("//c:fields/c:field[@name='IssueNumber']", resolver).DeleteSelf();
						navigator.SelectSingleNode("//c:fields/c:field[@name='Workstream']", resolver).DeleteSelf();
					}
					catch
					{
					}
				}
				try
				{
					string viewfilter = "";
					string sfilter = "";
					for (int i = 0; i < (int)condition.Length; i++)
					{
						sfilter = condition[i];
						if (sfilter.Contains(":$in"))
						{
							sfilter = sfilter.Replace(":$in$%js%", " In (");
							sfilter = sfilter.Replace("$or$%js%", ",");
							sfilter = string.Concat(sfilter, ")");
							sfilter = sfilter.Replace("\"", "'");
							sfilter = sfilter.Replace("\0", "");
							if (sfilter.Contains("\\/Date("))
							{
								sdate = sfilter.Substring(sfilter.IndexOf("\\/Date(") + 7, 12);
								sd1 = long.Parse(sdate);
								convdt = SharedBusinessRules.UnixTimestampToDateTime((double)(sd1 / (long)100));
								srep = string.Concat("\\/Date(", sdate, "0)\\/");
								sfilter = sfilter.Replace(srep, convdt.ToShortDateString());
							}
						}
						if (sfilter.Contains(":$notin"))
						{
							sfilter = sfilter.Replace(":$notin$%js%", " Not In (");
							sfilter = sfilter.Replace("$or$%js%", ",");
							sfilter = string.Concat(sfilter, ")");
							sfilter = sfilter.Replace("\"", "'");
							sfilter = sfilter.Replace("\0", "");
							if (sfilter.Contains("\\/Date("))
							{
								sdate = sfilter.Substring(sfilter.IndexOf("\\/Date(") + 7, 12);
								sd1 = long.Parse(sdate);
								convdt = SharedBusinessRules.UnixTimestampToDateTime((double)(sd1 / (long)100));
								srep = string.Concat("\\/Date(", sdate, "0)\\/");
								sfilter = sfilter.Replace(srep, convdt.ToShortDateString());
							}
						}
						else if (sfilter.Contains(":="))
						{
							sfilter = sfilter.Replace(":=%js%", "=");
							sfilter = sfilter.Replace("\"", "'");
							sfilter = sfilter.Replace("\0", "");
							if (sfilter.Contains("\\/Date("))
							{
								sdate = sfilter.Substring(sfilter.IndexOf("\\/Date(") + 7, 12);
								sd1 = long.Parse(sdate);
								convdt = SharedBusinessRules.UnixTimestampToDateTime((double)(sd1 / (long)100));
								srep = string.Concat("\\/Date(", sdate, "0)\\/");
								sfilter = sfilter.Replace(srep, convdt.ToShortDateString());
							}
						}
						else if (sfilter.Contains(":<>"))
						{
							sfilter = sfilter.Replace(":<>%js%", "<>");
							sfilter = sfilter.Replace("\"", "'");
							sfilter = sfilter.Replace("\0", "");
							if (sfilter.Contains("\\/Date("))
							{
								sdate = sfilter.Substring(sfilter.IndexOf("\\/Date(") + 7, 12);
								sd1 = long.Parse(sdate);
								convdt = SharedBusinessRules.UnixTimestampToDateTime((double)(sd1 / (long)100));
								srep = string.Concat("\\/Date(", sdate, "0)\\/");
								sfilter = sfilter.Replace(srep, convdt.ToShortDateString());
							}
						}
						else if (sfilter.Contains(":>"))
						{
							sfilter = sfilter.Replace(":>%js%", ">");
							sfilter = sfilter.Replace("\"", "'");
							sfilter = sfilter.Replace("\0", "");
							if (sfilter.Contains("\\/Date("))
							{
								sdate = sfilter.Substring(sfilter.IndexOf("\\/Date(") + 7, 12);
								sd1 = long.Parse(sdate);
								convdt = SharedBusinessRules.UnixTimestampToDateTime((double)(sd1 / (long)100));
								srep = string.Concat("\\/Date(", sdate, "0)\\/");
								sfilter = sfilter.Replace(srep, convdt.ToShortDateString());
							}
						}
						else if (sfilter.Contains(":<"))
						{
							sfilter = sfilter.Replace(":<%js%", "<");
							sfilter = sfilter.Replace("\"", "'");
							sfilter = sfilter.Replace("\0", "");
							if (sfilter.Contains("\\/Date("))
							{
								sdate = sfilter.Substring(sfilter.IndexOf("\\/Date(") + 7, 12);
								sd1 = long.Parse(sdate);
								convdt = SharedBusinessRules.UnixTimestampToDateTime((double)(sd1 / (long)100));
								srep = string.Concat("\\/Date(", sdate, "0)\\/");
								sfilter = sfilter.Replace(srep, convdt.ToShortDateString());
							}
						}
						else if (sfilter.Contains(":>="))
						{
							sfilter = sfilter.Replace(":>=%js%", ">=");
							sfilter = sfilter.Replace("\"", "'");
							sfilter = sfilter.Replace("\0", "");
						}
						else if (sfilter.Contains(":<="))
						{
							sfilter = sfilter.Replace(":<=%js%", "<=");
							sfilter = sfilter.Replace("\"", "'");
							sfilter = sfilter.Replace("\0", "");
						}
						viewfilter = string.Concat(viewfilter, sfilter, " AND ");
					}
					if (viewfilter.Trim().Length > 0)
					{
						viewfilter = viewfilter.Substring(0, viewfilter.Trim().Length - 5);
					}
					base.NodeSet().SelectView("grid1").SetFilter(sfilter);
				}
				catch
				{
				}
			}
			else if (!(controllerName != "NSA_Address_Info"))
			{
				if (srole != "admin")
				{
					try
					{
						navigator.SelectSingleNode("//c:actions/c:actionGroup[@id='ag103']", resolver).DeleteSelf();
					}
					catch
					{
					}
				}
				string stemplate = "\r\n                <action commandName=\"Custom\" commandArgument=\"Navigate\" headerText=\"@viewname\" id=\"a101@index\" xmlns=\"urn:schemas-codeontime-com:data-aquarium\">\r\n                    <data><![CDATA[@Viewid]]></data>\r\n                </action>";
				SqlText sql2 = new SqlText(string.Concat("Select [viewid],[viewname],viewispublic from NSA_View where useridentity='", suser, "' or viewispublic=1 order by [viewname] ASC"));
				int idx = 0;
				while (sql2.Read())
				{
					idx++;
					viewid = sql2.Reader.GetValue(0).ToString();
					string viewname = sql2.Reader.GetValue(1).ToString();
					string publicview = "";
					publicview = sql2.Reader.GetValue(2).ToString();
					publicview = ((publicview == null || publicview.Trim().Length == 0 ? false : !publicview.Trim().Contains("False")) ? " (Public)" : "");
					s = stemplate;
					s = s.Replace("@viewname", string.Concat(viewname, publicview));
					s = s.Replace("@Viewid", viewid);
					s = s.Replace("@index", idx.ToString());
					XmlDocument childNodes = new XmlDocument();
					childNodes.Load(new StringReader(s));
					XPathNavigator childNodesNavigator = childNodes.CreateNavigator();
					childNodesNavigator.MoveToFirstChild();
					navigator.SelectSingleNode("//c:actions/c:actionGroup[@id='ag102']", resolver).AppendChild(childNodesNavigator);
					findrole = new SqlText(string.Concat("SELECT [NSA_Role] FROM [NSA_PROJECT].[dbo].[NSA_USERS]  where 'AD-ENT\\' + [Ad-ENT ID] = '", suser, "'"));
					srole = "";
					if (findrole.Read())
					{
						srole = findrole.Reader.GetValue(0).ToString();
					}
					try
					{
						findrole.Close();
					}
					catch
					{
					}
				}
				sql2.Close();
            }
			}
            else if (!(base.Context.Session["Session_INVENTORY_TYPE"] == null ? true : !(base.Context.Session["Session_INVENTORY_TYPE"].ToString() == "LINE")))
            {
                base.NodeSet().SelectView("grid1").SetFilter("typename = 'LINE'");
            }
            else if ((base.Context.Session["Session_INVENTORY_TYPE"] == null ? false : base.Context.Session["Session_INVENTORY_TYPE"].ToString() == "CIRCUIT"))
            {
                base.NodeSet().SelectView("grid1").SetFilter("typename = 'CIRCUIT'");
            }
           
            if (!(base.Context.Session["Session_INVENTORY_DATA"] == null))
            {
                bool b =false;
                try
                {
                    if (navigator.SelectSingleNode("//c:command[@id='command1']/c:text", resolver).InnerXml.IndexOf("DATANETWORK")==-1) b=false;
                    else b=true;
                }
                catch { b = false; }
                if (b) base.NodeSet().SelectView("grid1").SetFilter("DATANETWORK = '" + base.Context.Session["Session_INVENTORY_DATA"].ToString() + "'");

            }
		}

		public override bool VirtualizeControllerConditionally(string controllerName)
		{
                string tname = "";
                string dname = "";

                if (controllerName == "NSA_INVENTORY_STAGE")
                {
     
                    try
                    {
                        string[] viewfilter = base.Page.Filter;
                        for (int i = 0; i < viewfilter.Length; i++)
                        {
                            if (viewfilter[i].Contains("typename"))
                            {
                                tname = viewfilter[i].Replace("typename:=%js%", "");
                                tname = tname.Replace("\"", "");
                            }
                            if (viewfilter[i].Contains("DATANETWORK"))
                            {
                                dname = viewfilter[i].Replace("DATANETWORK:=%js%", "");
                                dname = dname.Replace("\"", "");
                            }
                        }


                        if (tname.Contains("CIRCUIT"))
                        {
                            base.Context.Session["Session_INVENTORY_TYPE"] = "CIRCUIT";

                            if (dname.Length > 0)
                            {
                                base.Context.Session["Session_INVENTORY_DATA"] = dname;
                            }
                            else
                            {
                                base.Context.Session.Remove("Session_INVENTORY_DATA");
                            }
                        }
                        else if (tname.Contains("LINE"))
                        {
                            base.Context.Session["Session_INVENTORY_TYPE"] = "LINE";
                        }
                        else base.Context.Session.Remove("Session_INVENTORY_TYPE");
                    }
                    catch
                    {
                        base.Context.Session.Remove("Session_INVENTORY_TYPE");
                    }
                }
           
        
            return base.VirtualizeControllerConditionally(controllerName);
		}

		[ControllerAction("NSA_Address_Info", "Custom", "WLAN")]
		public void WLAN1()
		{
			FilterValue[] filterValue = new FilterValue[1];
			object[] objArray = new object[] { "OOS" };
			filterValue[0] = new FilterValue("WLANDeploy", RowFilterOperation.DoesNotEqual, objArray);
			base.AssignFilter(filterValue);
			base.Result.Refresh();
		}

		public struct USER_INFO_10
		{
			public string usri10_name;

			public string usri10_comment;

			public string usri10_usr_comment;

			public string usri10_full_name;
		}
	}
}