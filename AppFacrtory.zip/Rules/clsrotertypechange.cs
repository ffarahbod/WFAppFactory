﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using Wells_Fargo.Data;

namespace Wells_Fargo.Rules
{
    public partial class clsrotertypechange : Wells_Fargo.Rules.SharedBusinessRules
    {
        //[ControllerAction("ctlSiteReadinessIPTBOM", "Calculate", "BOMROUTERTYPE")]
        //private void resetRouterParts(int? EVM, int? FXO_FXS, int? FXO, int? VG224, string SMX1T3E3, int?  VIC34FXSDID, int? VIC24FXO, int? PVDM3_32, string SL39UCK9, int? FLCMESRST25, int FLCMESRST100, string VWIC34MFTT1E1)
        //{
        //    string rttype = SelectFieldValue("BOMROUTERTYPE").ToString();

        //    if (rttype.Trim()=="2921")
        //    {
        //        //UpdateFieldValue ("FXO",0);
        //        //UpdateFieldValue ("VG224",0);
        //        //UpdateFieldValue ("SMX1T3E3","0");
        //        //UpdateFieldValue ("VIC34FXSDID",0);
        //        //UpdateFieldValue ("VIC24FXO",0);
        //        //UpdateFieldValue ("PVDM3_32",0);
        //        //UpdateFieldValue ("SL39UCK9","0");
        //        //UpdateFieldValue ("FLCMESRST100",0);
        //        //UpdateFieldValue("VWIC34MFTT1E1", 0);
        //        //return;

        //    }
        //    else if (rttype.Trim() == "3945") 
        //    {
        //        //UpdateFieldValue ("PVDM3_32",0);
        //        //UpdateFieldValue ("FXO_FXS",0);
        //        //UpdateFieldValue ("VIC34FXSDID",0);
        //        //UpdateFieldValue ("VIC24FXO",0);
        //        //UpdateFieldValue ("SL39UCK9",0);
        //        //UpdateFieldValue ("VG224",0);
        //        //UpdateFieldValue ("VWIC34MFTT1E1",0);
        //        //return;

        //    }

        //    else if (rttype.Trim() == "Parts Only")
        //    {
        //         //UpdateFieldValue ("FXO",0);
        //         //UpdateFieldValue ("FXO_FXS",0);
        //         //UpdateFieldValue ("VG224",0);
        //         //UpdateFieldValue ("EVM",0);
        //         //UpdateFieldValue ("SMX1T3E3","0");


        //    }

        //    else
        //    {
        //        //UpdateFieldValue("FXO", 0);
        //        //UpdateFieldValue("VG224", 0);
        //        //UpdateFieldValue("SMX1T3E3", "0");
        //        //UpdateFieldValue("VIC34FXSDID", 0);
        //        //UpdateFieldValue("VIC24FXO", 0);
        //        //UpdateFieldValue("PVDM3_32", 0);
        //        //UpdateFieldValue("SL39UCK9", "0");
        //        //UpdateFieldValue("FLCMESRST100", 0);
        //        //UpdateFieldValue("FLCMESRST25", 0);
        //        //UpdateFieldValue("VWIC34MFTT1E1", 0);
        //        //UpdateFieldValue("PVDM3_32", 0);
        //        //UpdateFieldValue("FXO_FXS", 0);
        //        //UpdateFieldValue("VIC34FXSDID", 0);
        //        //UpdateFieldValue("VIC24FXO", 0);
        //        //UpdateFieldValue("SL39UCK9", 0);
        //        //UpdateFieldValue("VG224", 0);
        //        //UpdateFieldValue("VWIC34MFTT1E1", 0);
        //        //UpdateFieldValue("FXO", 0);
        //        //UpdateFieldValue("FXO_FXS", 0);
        //        //UpdateFieldValue("VG224", 0);
        //        //UpdateFieldValue("EVM", 0);
        //        //UpdateFieldValue("SMX1T3E3", "0");
        //        //return;

        //    }
        //}
    }
}
