﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Security;
using Wells_Fargo.Data;

namespace Wells_Fargo.Rules
{
	public partial class ctlSiteReadinessprojectInfoBusinessRules : Wells_Fargo.Rules.SharedBusinessRules
    {
        
        /// <summary>
        /// Rule "validatereasons" implementation:
        /// This method will execute in any view before an action
        /// with a command name that matches "Update".
        /// </summary>
        [Rule("r101")]
        public void r101Implementation(
                    string sITE_ALIAS, 
                    string rETAIL_NAME, 
                    string lDN, 
                    string cOUNTRY, 
                    string aDDRESS3, 
                    string mAC_STATUS, 
                    string oPENDATE, 
                    string cLOSEDATE, 
                    string pHONE1, 
                    string pHONE2, 
                    string fAX, 
                    string mAC, 
                    string floor, 
                    int? iD, 
                    string wLANDeploy, 
                    string wLANPhase, 
                    string flPlaninSMS, 
                    string wSSIMonitor, 
                    string partlFlr, 
                    string iPTYNexisting, 
                    string iPTPhase, 
                    string routerName, 
                    string rtrMdlCurrent, 
                    string routerRefr, 
                    string currentBndwdth, 
                    string bndwdthUpgrdyesno, 
                    string recmdUpgrdCktsize, 
                    string siteNotes, 
                    string cPGEVENT, 
                    string region_New, 
                    string majorMarket, 
                    string complex, 
                    string mainBranch, 
                    string branchID, 
                    string branchName, 
                    string users, 
                    double? devcs, 
                    double? fAXAnalogFXSports, 
                    string eUCRegn, 
                    string configCntrWLAN, 
                    string vendorWLANNtwk, 
                    string issuenotes, 
                    DateTime? predSurvDue, 
                    DateTime? predSurvActual, 
                    double? wSSIsReqd, 
                    double? aPsReqd, 
                    string switchRefr, 
                    double? pwrInjsRqrd, 
                    DateTime? wLANBOMposted, 
                    DateTime? wLANCutShtSenttoCC, 
                    DateTime? wLANCutShtCCReply, 
                    string cntrllr1Assgnmt, 
                    string cntrllr2Assgnmt, 
                    string switchCpctyPortsAvlb, 
                    string wSSIAssgnmt, 
                    DateTime? comm4wkSentWLAN, 
                    DateTime? eProreqwlanDate, 
                    string eProReqVendorWLAN, 
                    string wLANSR, 
                    DateTime? preInstallSurveyDateIfRequired, 
                    DateTime? wLANInstallPlannedDate, 
                    DateTime? wLANInstallActualDate, 
                    DateTime? wLANPostSurveyCompltnDate, 
                    DateTime? postInstallActualDate, 
                    DateTime? siteVisitReschedule, 
                    string wLANStatus, 
                    string eUCCoordinator, 
                    string mACCode, 
                    string address1, 
                    string address2, 
                    string city, 
                    string state, 
                    string zipCode, 
                    string mainPhone, 
                    string tollFreeNumber, 
                    string faxanalognumbers, 
                    string bRMGR, 
                    string bSA, 
                    string nEWAU, 
                    string pFAUs, 
                    string pFBranchCodes, 
                    string branchPOB, 
                    string branchServerName, 
                    string predSurvTech, 
                    DateTime? rtrCktUpgrActual,
                    FieldValue rtrCktUpgrPlanned, 
                    DateTime? iPTConversionDateActual, 
                    DateTime? iPTConversionDatePlanned, 
                    string iPTSiteStatus, 
                    DateTime? modified, 
                    string modifiedBy, 
                    string priority, 
                    string routerUpgrStatus, 
                    string readinessDeploy, 
                    string sqFt, 
                    string wLANCR, 
                    string wLANFlrs, 
                    string wLANNetEng, 
                    string wLANSize, 
                    double? phoneSets, 
                    double? paging911FXOports, 
                    string work, 
                    double? n2921RTRReqd, 
                    double? n3750xSwReqd, 
                    string n3945RTRReqd, 
                    string n911DetermineQty, 
                    DateTime? n911CarrierDueDate, 
                    string n911Linenumber, 
                    string n911MatrixRequest, 
                    string n911PortAssignments, 
                    string benchRouterType, 
                    string benchSwitchType, 
                    string br2ndContact, 
                    string cktCarrierDueDate, 
                    DateTime? cktExtensionPlanned, 
                    string cktMatrixRequest, 
                    DateTime? cktOrdered, 
                    DateTime? cktReqstdDue, 
                    string cktUpgLeadTime, 
                    string cktUpgrStatus, 
                    string cktUpgrType, 
                    string cktRtrCR, 
                    string clusterAlias, 
                    string clusterBias, 
                    string cMPCTLorder, 
                    string cMPOrderfor911lines, 
                    string cMPOrderforAlarmlines, 
                    string cMPVZNOrder, 
                    string cntrllrType, 
                    string cOI, 
                    DateTime? comm1wkSentWLAN, 
                    string conferencebridge, 
                    string contentType, 
                    bool? cRApprvdWLAN, 
                    DateTime? created, 
                    string createdBy, 
                    string cSRScrubCompleted, 
                    DateTime? cTLCktDelvrd, 
                    string cTLcktnewIPCE, 
                    string cTLcktnewIPPE, 
                    string cTLcktnewsubnet, 
                    DateTime? cTLFOC, 
                    string cTLNewCktID, 
                    string cTLnewLECID, 
                    DateTime? cTLScriptReceived, 
                    string demarcLctn, 
                    string dIDNumbersNew, 
                    string dIDnumbersporting, 
                    string dIDRangeDetermineNeed, 
                    string dIDRangeDetermineQty, 
                    DateTime? dIDRangeCarrierDueDate, 
                    string dIDRangeMatrixRequest, 
                    string dNSdomainname, 
                    string eMHDA6FXO, 
                    string ePTSORC, 
                    string eUCVoicePM, 
                    string eVMHD8FXSDID, 
                    string fXOportfor911, 
                    string fXOportforpaging, 
                    bool? hardwareBenched, 
                    bool? hardwareConfigured, 
                    bool? hardwareShipped, 
                    string hostnameIPDomainNameDNSName, 
                    string internalDialing, 
                    string iPTNetEng, 
                    string iPTNetScrub, 
                    string iPTSwitchReplacement, 
                    string iPTTTDate, 
                    string issueOwner, 
                    DateTime? issueStart, 
                    string iSSUEStatus, 
                    string issueType, 
                    string loopback1address, 
                    string mEM2900512U25GB, 
                    string mEM39001GU2GB, 
                    string mEMCF256U1GB, 
                    string mEMCF256U512MB, 
                    string moduleslotforEVMFXS, 
                    string mOHServerIPAddress, 
                    string netSecEngr, 
                    string netSecStatus, 
                    string numberofDIDsNeeded, 
                    string numbersPortable, 
                    string paging, 
                    string partofE911Project, 
                    string portAssignmentsAnalog, 
                    string publisherIPAddress, 
                    string publisherName, 
                    string pVDM332, 
                    string pVDM364, 
                    string rEFRESHType, 
                    string routerType, 
                    string rTRProjPhoenix, 
                    bool? sitesCompleted, 
                    string sL29UCK9, 
                    string sL39UCK9, 
                    string sMNMADPTR, 
                    string sMX1T3E3, 
                    string sonusCallControlPlatform, 
                    string sonusCSN, 
                    string sonusELSTierMarket, 
                    string sonusLata, 
                    string sonusLocalInboundCoverage, 
                    string sonusLocalInboundTierMarket, 
                    string sonusRCABBR, 
                    string sonusRCSTATE, 
                    string sonusSiteBias, 
                    string subscriber1IPAddress, 
                    string subscriber1Name, 
                    string subscriber2IPAddress, 
                    string subscriber2Name, 
                    string sWProjPhoenix, 
                    string switchADD, 
                    string switchModel, 
                    string switchName, 
                    string tFTP1IPAddress, 
                    string tFTP1Name, 
                    string tFTP2IPAddress, 
                    string tFTP2Name, 
                    string unityIPAddress, 
                    string unityName, 
                    string vG224EVMFXSFXO, 
                    string vIC24FXO, 
                    string vIC34FXSDID, 
                    bool? voiceInfocomplete, 
                    string vRZcktnewIPCE, 
                    string vRZcktnewIPPE, 
                    string vRZcktnewsubnet, 
                    string vRZnewCktID, 
                    string vRZnewLECID, 
                    DateTime? vRZScriptReceived, 
                    string vWIC34MFTT1E1, 
                    DateTime? vZNCktDelvrd, 
                    DateTime? vZNFOC, 
                    string itemType, 
                    string br2ndContactNumber, 
                    string project, 
                    string predSurveyReq, 
                    string bOMPosted, 
                    string wLANBOMRequired, 
                    string switchBOMRequired, 
                    string vLAN16, 
                    string vLAN816, 
                    string n3750xSwNotes, 
                    DateTime? wSSIAssignmentDateComplete, 
                    string actualCKTUpgradeSize, 
                    string eUCRegionSRNo, 
                    bool? siteReadinessSiteRescheduled,
                    FieldValue rtrCktUpgrOriginalPlannedDate,
                    FieldValue rtrcktupgDateChangereason, 
                    FieldValue rtrCktoriginalDateChangereason)
        {

            FieldValue rk1 = SelectFieldValueObject("rk1");
            if (rk1.Value == null) goto rk2;
            if ((rtrCktUpgrPlanned.OldValue == null && rtrCktUpgrPlanned.NewValue != null) || (rtrCktUpgrPlanned.OldValue != null && rtrCktUpgrPlanned.NewValue == null))
            {
                if (rtrcktupgDateChangereason.Value == null)
                {
                    Result.ExecuteOnClient("this._focus('rtrcktupgDateChangereason', 'RTR/CKT Upg Planned has been changed, A Reason text must be entered.')");
                    throw new Exception("Please enter 'RTR/CKT Upg Planned' Reason and try again!");

                }
                else
                {
                    SqlText sql = null;
                    if (rtrCktUpgrPlanned.NewValue == null)
                    {
                        sql = new SqlText("insert into DatesHistorylog (tablename, columnname,parentid,oldvalue, newvalue,ModifiedDate,ModifyUser,Reason) values('NSA_Address_Info','Rtr/Ckt Upgr Planned'," + iD.ToString() + ",'" + rtrCktUpgrPlanned.OldValue.ToString() + "',NULL,getDate(),'" + Context.User.Identity.Name + "','" + rtrcktupgDateChangereason.Value.ToString() + "')");

                    }
                    else
                    {
                        sql = new SqlText("insert into DatesHistorylog (tablename, columnname,parentid,oldvalue, newvalue,ModifiedDate,ModifyUser,Reason) values('NSA_Address_Info','Rtr/Ckt Upgr Planned'," + iD.ToString() + ",NULL,'" + rtrCktUpgrPlanned.NewValue.ToString() + "',getDate(),'" + Context.User.Identity.Name + "','" + rtrcktupgDateChangereason.Value.ToString() + "')");

                    }
                    int i = sql.ExecuteNonQuery();
                    //rtrcktupgDateChangereason.NewValue = "";
                    //rtrcktupgDateChangereason.Value = null;
                    //UpdateFieldValue("rtrcktupgDateChangereason", null);
                    rtrcktupgDateChangereason.Modified = false;
                    try
                    {
                        sql.Close();
                        sql.Dispose(true);

                    }
                    catch { }
                }

            }
            else if ((rtrCktUpgrPlanned.OldValue !=null && rtrCktUpgrPlanned.NewValue !=null) && rtrCktUpgrPlanned.OldValue.ToString() != rtrCktUpgrPlanned.NewValue.ToString())
            {
                if (rtrcktupgDateChangereason.Value == null)
                {
                    Result.ExecuteOnClient("this._focus('rtrcktupgDateChangereason', 'RTR/CKT Upg Planned has been changed, A Reason text must be entered.')");
                    throw new Exception("Please enter 'RTR/CKT Upg Planned' Reason and try again!");

                }
                else
                {
                    SqlText sql = new SqlText("insert into DatesHistorylog (tablename, columnname,parentid,oldvalue, newvalue,ModifiedDate,ModifyUser,Reason) values('NSA_Address_Info','Rtr/Ckt Upgr Planned'," + iD.ToString() + ",'" + rtrCktUpgrPlanned.OldValue.ToString() + "','" + rtrCktUpgrPlanned.NewValue.ToString() + "',getDate(),'" + Context.User.Identity.Name + "','" + rtrcktupgDateChangereason.Value.ToString() + "')");

                    int i = sql.ExecuteNonQuery();
                    //rtrcktupgDateChangereason.NewValue = "";
                    //rtrcktupgDateChangereason.Value = null;
                    //UpdateFieldValue("rtrcktupgDateChangereason", null);
                    rtrcktupgDateChangereason.Modified = false;
                    try
                    {
                        sql.Close();
                        sql.Dispose(true);

                    }
                    catch { }
                }




            }

            else
            {

                rtrcktupgDateChangereason.Modified = false;


            }
            rk2:
            FieldValue rk2 = SelectFieldValueObject("rk2");
            if (rk2.Value == null) return;
            if ((rtrCktUpgrOriginalPlannedDate.OldValue == null && rtrCktUpgrOriginalPlannedDate.NewValue != null) || (rtrCktUpgrOriginalPlannedDate.OldValue != null && rtrCktUpgrOriginalPlannedDate.NewValue == null))
            {
                if (rtrCktoriginalDateChangereason.Value == null)
                {
                    Result.ExecuteOnClient("this._focus('RtrCktoriginalDateChangereason', 'RTRCKTUpgdOriginalDate has been changed, A Reason text must be entered.')");
                    throw new Exception("Please enter 'RTRCKTUpgdOriginalDate' Reason and try again!");

                }
                else
                {
                    SqlText sql = null;
                    if (rtrCktUpgrOriginalPlannedDate.NewValue == null)
                    {
                        sql = new SqlText("insert into DatesHistorylog (tablename, columnname,parentid,oldvalue, newvalue,ModifiedDate,ModifyUser,Reason) values('NSA_Address_Info','Rtr Ckt Upgr Original Planned Date'," + iD.ToString() + ",'" + rtrCktUpgrOriginalPlannedDate.OldValue.ToString() + "',NULL,getDate(),'" + Context.User.Identity.Name + "','" + rtrCktUpgrOriginalPlannedDate.Value.ToString() + "')");
                    }
                    else
                    {
                        sql = new SqlText("insert into DatesHistorylog (tablename, columnname,parentid,oldvalue, newvalue,ModifiedDate,ModifyUser,Reason) values('NSA_Address_Info','Rtr Ckt Upgr Original Planned Date'," + iD.ToString() + ",NULL,'" + rtrCktUpgrOriginalPlannedDate.NewValue.ToString() + "',getDate(),'" + Context.User.Identity.Name + "','" + rtrCktUpgrOriginalPlannedDate.Value.ToString() + "')");
                    }

                    int i = sql.ExecuteNonQuery();
                    rtrCktoriginalDateChangereason.Modified = false;
                    try
                    {
                        sql.Close();
                        sql.Dispose(true);

                    }
                    catch { }
                }
            }
            else if ((rtrCktUpgrOriginalPlannedDate.OldValue != null && rtrCktUpgrOriginalPlannedDate.NewValue != null) && (rtrCktUpgrOriginalPlannedDate.OldValue.ToString() != rtrCktUpgrOriginalPlannedDate.NewValue.ToString()))
            {
                if (rtrCktoriginalDateChangereason.Value == null)
                {
                    Result.ExecuteOnClient("this._focus('RtrCktoriginalDateChangereason', 'RTRCKTUpgdOriginalDate has been changed, A Reason text must be entered.')");
                    throw new Exception("Please enter 'RTRCKTUpgdOriginalDate' Reason and try again!");

                }
                else
                { 
                    SqlText sql = new SqlText("insert into DatesHistorylog (tablename, columnname,parentid,oldvalue, newvalue,ModifiedDate,ModifyUser,Reason) values('NSA_Address_Info','Rtr Ckt Upgr Original Planned Date'," + iD.ToString() + ",'" + rtrCktUpgrOriginalPlannedDate.OldValue.ToString() + "','" + rtrCktUpgrOriginalPlannedDate.NewValue.ToString() + "',getDate(),'" + Context.User.Identity.Name + "','" + rtrCktoriginalDateChangereason.Value.ToString() + "')");

                    int i = sql.ExecuteNonQuery();

                    rtrCktoriginalDateChangereason.Modified = false;
                    try
                    {
                        sql.Close();
                        sql.Dispose(true);

                    }
                    catch { }
                }




            }

            else
            {

                rtrCktoriginalDateChangereason.Modified = false;



            }

           
        }
    }
}
