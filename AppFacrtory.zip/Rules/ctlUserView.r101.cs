﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Security;
using Wells_Fargo.Data;

namespace Wells_Fargo.Rules
{
	public partial class ctlUserViewBusinessRules : Wells_Fargo.Rules.SharedBusinessRules
    {
        
        /// <summary>
        /// This method will execute in any view for an action
        /// with a command name that matches "Custom" and argument that matches "Preview".
        /// </summary>
        [Rule("r101")]
        public void r101Implementation(int? viewid, string viewname, string useridentity)
        {

            

            SqlText sql = new SqlText("Update NSA_View set ViewSelected=0 where useridentity='" + Context.User.Identity.Name + "'");
            sql.ExecuteNonQuery();
            sql.Close();

            sql = new SqlText("Update NSA_View set ViewSelected=1 where viewid=" + viewid);
            sql.ExecuteNonQuery();
            sql.Close();
            Result.NavigateUrl = "AllItems.aspx";
        }
    }
}
