using System;
using System.Security.Principal;
using System.Web;
using Wells_Fargo.Data;

namespace Wells_Fargo.Rules
{
	public class ctlPrivateViewBusinessRules : SharedBusinessRules
	{
		public ctlPrivateViewBusinessRules()
		{
		}

		[Rule("r102")]
		public void r102Implementation(int? viewid, string viewname, string viewCondition, string user_identity)
		{
			SqlText sq = new SqlText(string.Concat("Delete from  NSA_View_Fields_Draft where username='", base.Context.User.Identity.Name, "'"));
			sq.ExecuteNonQuery();
			sq.Close();
			sq = new SqlText(string.Concat("Delete from  View_Filter_Draft where userIdentity='", base.Context.User.Identity.Name, "'"));
			sq.ExecuteNonQuery();
			sq.Close();
			object[] name = new object[] { "Insert into NSA_View_Fields_Draft (tablename,fieldid,username,sequence) select 'NSA_Address_Info',fieldid,'", base.Context.User.Identity.Name, "',sequence from NSA_View_Fields where Viewid=", viewid };
			sq = new SqlText(string.Concat(name));
			sq.ExecuteNonQuery();
			sq.Close();
			sq = new SqlText(string.Concat("Update NSA_View_Fields_Draft set visible=1 where username='", base.Context.User.Identity.Name, "'"));
			sq.ExecuteNonQuery();
			sq.Close();
			sq = new SqlText(string.Concat("Update NSA_View_Fields_Draft set NSA_View_Fields_Draft.OrderBy=NSA_View_Fields.orderby from NSA_View_Fields inner join NSA_View_Fields_Draft on NSA_View_Fields_Draft.fieldid=NSA_View_Fields.fieldid where NSA_View_Fields.viewid=", viewid));
			sq.ExecuteNonQuery();
			sq.Close();
			name = new object[] { "Insert into View_Filter_Draft (useridentity,ViewFilter) select '", base.Context.User.Identity.Name, "',[ViewCondition]from [NSA_View]where viewid=", viewid };
			sq = new SqlText(string.Concat(name));
			sq.ExecuteNonQuery();
			sq.Close();
			base.Result.ExecuteOnClient("$appfactory.find('ctlNSA_View_Fields_Draft','Controller').sync();");
		}
	}
}